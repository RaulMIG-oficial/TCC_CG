﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC_CG_0._0._0._2
{
	public partial class Cadastro : Form
	{
		public Cadastro()
		{
			InitializeComponent();
		}
		private int baralhoId = 0;
		private void Cadastro_Load(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			string nome = textBox1.Text;
			string senha = textBox2.Text;
			string senhaHash = Cripto_Hash.GerarHashSha256(senha);
			JogadorRepository repo = new JogadorRepository(CodBD.connection);
			Jogador jogador = repo.ObterPorNome(nome);
			if (jogador.Nome != "Fall")
			{
				label6.Text = "> Erro: O nome já está cendo utilizado";
				return;
			}
			if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(senha))
			{
				label6.Text = "> Erro: Preencha todos os campos";
				return;
			}
			if ((radioButton1.Checked == false) && (radioButton2.Checked == false) && (radioButton3.Checked == false))
			{
				label6.Text = "> Erro: Escolha um baralho";
				return;
			}
			if (nome.Length < 4)
			{
				label6.Text = "> Erro: Nome muito pequeno, pelo menos 4 caracteres";
				return;
			}
			if (senha.Length < 6)
			{
				label6.Text = "> Erro: A senha deve ter pelo menos 6 caracteres.";
				return;
			}
			BaralhoRepository baralhorepo = new BaralhoRepository(CodBD.connection);
			Baralho baralho = baralhorepo.ObterBaralhoBasePorId(baralhoId);

			Jogador novoJogador = new Jogador
			{
				Nome = nome,
				Senha = senhaHash,
				BaralhoBase = baralho.Cartas,
				BaralhoGlobal = baralho.Cartas,
			};
			try
			{
				int linhas = repo.InserirJogador(novoJogador,baralho.Id,baralho.Id);
				if (linhas > 0)
				{
					label6.ForeColor = Color.Green;
					label6.Text = "Boa moleke. Cadastrado com sucesso!";
					LimparCampos();
				}
				else
				{
					label6.Text = "Erro ao cadastrar.";
				}
			}
			catch (MySql.Data.MySqlClient.MySqlException ex)
			{
				if (ex.Number == 1062)
					label6.Text = "O nome já está sendo usado";
			}
			catch (Exception ex)
			{
				label6.Text = "Erro inesperado: " + ex.Message;
			}
		}
		private void LimparCampos()
		{
			textBox1.Text = "";
			textBox2.Text = "";
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			label5.Text = "O baralho tem:\n 5 cartas de Golpe (6 de dano cada)\n 4 cartas de Defender (5 de defesa cada)\n 2 cartas de Cura (4 de cura cada)";
			baralhoId = 1;
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			label5.Text = "O baralho tem:\n 4 cartas de Golpe (6 de dano cada)\n 5 cartas de Defender (5 de defesa cada)\n 2 cartas de Cura (4 de cura cada)";
			baralhoId = 2;
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			label5.Text = "O baralho tem:\n 3 cartas de Golpe (6 de dano cada)\n 5 cartas de Defender (5 de defesa cada)\n 3 cartas de Cura (4 de cura cada)";
			baralhoId = 3;
		}
	}
}

