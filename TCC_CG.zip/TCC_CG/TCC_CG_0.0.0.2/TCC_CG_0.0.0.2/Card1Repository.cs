﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._2
{
	internal class Card1Repository
	{
		private readonly string _connectionString;

		public Card1Repository(string connectionString)
		{
			_connectionString = connectionString;
		}
		public Card1 ObterCartaPeloId(int IdCarta)
		{

			Card1 card = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT nome_carta, dano, defesa, regeneração FROM Cartas WHERE id_carta = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", IdCarta);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							card = new Card1
							{
								Id = IdCarta,
								Dano = Convert.ToInt32(reader.GetString("dano")),
								Defesa = Convert.ToInt32(reader.GetString("defesa")),
								Cura = Convert.ToInt32(reader.GetString("regeneração")),
								Nome = reader.GetString("nome_carta")
							};
						}
					}
				}
			}
			return card;
		}

	}
}
