﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._2
{
	internal class CodBD
	{
		public string email_usuario = null;
		public static string connection { get; } = "server=localhost;database=tcc_card_gamer0.0.0.2;uid=root;pwd=;";
		public CodBD(string email)
		{
			email_usuario = email;
		}
	}
}
