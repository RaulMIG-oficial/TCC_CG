namespace TCC_CG_0._0._0._2
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Cadastro cadastro = new Cadastro();
			this.Hide();
			cadastro.ShowDialog();
			this.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			string nome1 = textBox1.Text;
			string senha1 = textBox2.Text;
			string nome2 = textBox4.Text;
			string senha2 = textBox3.Text;
			string senhaHash1 = Cripto_Hash.GerarHashSha256(senha1);
			string senhaHash2 = Cripto_Hash.GerarHashSha256(senha2);
			JogadorRepository repo = new JogadorRepository(CodBD.connection);
			if (string.IsNullOrWhiteSpace(nome1) || string.IsNullOrWhiteSpace(senha1) ||
				string.IsNullOrWhiteSpace(nome2) || string.IsNullOrWhiteSpace(senha2))
			{
				label7.Text = "> Erro: Preencha todos os campos";
				return;
			}
			Jogador play1 = repo.ObterPorNomeESenha(nome1, senhaHash1);
			Jogador play2 = repo.ObterPorNomeESenha(nome2, senhaHash2);
			if (play1 == null)
			{
				label7.Text = "> Jogador 1 n�o encontrado";
				return;
			}
			if (play2 == null)
			{
				label7.Text = "> Jogador 2 n�o encontrado";
				return;
			}
			if ((play1 != null) && (play2 != null) && (play1 != play2))
			{
				Jogo jogo = new Jogo(play1,play2);
				this.Hide();
				jogo.ShowDialog();
				this.Show();

			}

		}
	}
}
