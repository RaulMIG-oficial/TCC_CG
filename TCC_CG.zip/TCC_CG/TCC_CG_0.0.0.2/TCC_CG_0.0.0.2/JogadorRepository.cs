﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._2
{
	internal class JogadorRepository
	{
		private readonly string _connectionString;

		public JogadorRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		public Jogador ObterPorNomeESenha(string nome, string senha)
		{
			Jogador usuario = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT nome_usuario, senha, lvl, id_baralho_base, id_baralho_global, win, lose FROM jogador WHERE nome_usuario = @Nome AND senha = @Senha";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Nome", nome);
					command.Parameters.AddWithValue("@Senha", senha);

					using (var reader = command.ExecuteReader())
					{
						BaralhoRepository baralhorepo = new BaralhoRepository(_connectionString);
						
						if (reader.Read())
						{
							Baralho baralhoB = baralhorepo.ObterBaralhoBasePorId(reader.GetInt32("id_baralho_base"));
							Baralho baralhoG = baralhorepo.ObterBaralhoGlobalPorId(reader.GetInt32("id_baralho_global"));
							usuario = new Jogador
							{
								Nome = reader.GetString("nome_usuario"),
								Senha = reader.GetString("senha"),
								lvl = reader.GetInt32("lvl"),
								BaralhoBase = baralhoB.Cartas,
								BaralhoGlobal = baralhoG.Cartas,
								Win = reader.GetInt32("win"),
								Lose = reader.GetInt32("lose")
							};
						}
					}
				}
			}
			return usuario;
		}
		public Jogador ObterPorNome(string nome)
		{
			Jogador usuario = new Jogador { Nome = "Fall" };
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT nome_usuario FROM jogador WHERE nome_usuario = @Nome ";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Nome", nome);
					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							usuario = new Jogador
							{
								Nome = reader.GetString("nome_usuario"),
							};
						}
					}
				}
			}
			return usuario;
		}
		public int InserirJogador(Jogador usuario,int IdBB,int IdBG)
		{
			int linhasAfetadas = -1;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "INSERT INTO Jogador (nome_usuario, lvl, senha,id_baralho_base,id_baralho_global,Win,Lose) VALUES (@Nome, @Lvl, @Senha, @IdBB, @IdBG, @Win, @Lose)";
				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@Nome", usuario.Nome);
					command.Parameters.AddWithValue("@Lvl", usuario.lvl);
					command.Parameters.AddWithValue("@Senha", usuario.Senha);
					command.Parameters.AddWithValue("@IdBB", IdBB);
					command.Parameters.AddWithValue("@IdBG", IdBG);
					command.Parameters.AddWithValue("@Win", usuario.Win);
					command.Parameters.AddWithValue("@Lose", usuario.Lose);

					linhasAfetadas = command.ExecuteNonQuery();
				}
			}
			return linhasAfetadas;
		}
	}
}
