﻿namespace TCC_CG_0._0._0._2
{
	partial class Jogo
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			checkedListBox1 = new CheckedListBox();
			checkedListBox2 = new CheckedListBox();
			checkedListBox3 = new CheckedListBox();
			checkedListBox4 = new CheckedListBox();
			radioButton1 = new RadioButton();
			radioButton2 = new RadioButton();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			label8 = new Label();
			label9 = new Label();
			label10 = new Label();
			radioButton3 = new RadioButton();
			radioButton4 = new RadioButton();
			checkedListBox5 = new CheckedListBox();
			checkedListBox6 = new CheckedListBox();
			checkedListBox7 = new CheckedListBox();
			checkedListBox8 = new CheckedListBox();
			label11 = new Label();
			label12 = new Label();
			label13 = new Label();
			label14 = new Label();
			button1 = new Button();
			label15 = new Label();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(12, 9);
			label1.Name = "label1";
			label1.Size = new Size(55, 15);
			label1.TabIndex = 0;
			label1.Text = "Jogador1";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(12, 35);
			label2.Name = "label2";
			label2.Size = new Size(27, 15);
			label2.TabIndex = 1;
			label2.Text = "LvL:";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(12, 50);
			label3.Name = "label3";
			label3.Size = new Size(26, 15);
			label3.TabIndex = 2;
			label3.Text = "HP:";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(12, 65);
			label4.Name = "label4";
			label4.Size = new Size(40, 15);
			label4.TabIndex = 3;
			label4.Text = "Mana:";
			// 
			// checkedListBox1
			// 
			checkedListBox1.FormattingEnabled = true;
			checkedListBox1.Location = new Point(12, 101);
			checkedListBox1.Name = "checkedListBox1";
			checkedListBox1.Size = new Size(118, 22);
			checkedListBox1.TabIndex = 4;
			// 
			// checkedListBox2
			// 
			checkedListBox2.FormattingEnabled = true;
			checkedListBox2.Location = new Point(12, 129);
			checkedListBox2.Name = "checkedListBox2";
			checkedListBox2.Size = new Size(118, 22);
			checkedListBox2.TabIndex = 5;
			// 
			// checkedListBox3
			// 
			checkedListBox3.FormattingEnabled = true;
			checkedListBox3.Location = new Point(12, 157);
			checkedListBox3.Name = "checkedListBox3";
			checkedListBox3.Size = new Size(118, 22);
			checkedListBox3.TabIndex = 6;
			// 
			// checkedListBox4
			// 
			checkedListBox4.FormattingEnabled = true;
			checkedListBox4.Location = new Point(12, 185);
			checkedListBox4.Name = "checkedListBox4";
			checkedListBox4.Size = new Size(118, 22);
			checkedListBox4.TabIndex = 7;
			// 
			// radioButton1
			// 
			radioButton1.AutoSize = true;
			radioButton1.Location = new Point(12, 255);
			radioButton1.Name = "radioButton1";
			radioButton1.Size = new Size(94, 19);
			radioButton1.TabIndex = 8;
			radioButton1.TabStop = true;
			radioButton1.Text = "radioButton1";
			radioButton1.UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			radioButton2.AutoSize = true;
			radioButton2.Location = new Point(12, 280);
			radioButton2.Name = "radioButton2";
			radioButton2.Size = new Size(94, 19);
			radioButton2.TabIndex = 9;
			radioButton2.TabStop = true;
			radioButton2.Text = "radioButton2";
			radioButton2.UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(12, 80);
			label5.Name = "label5";
			label5.Size = new Size(31, 15);
			label5.TabIndex = 10;
			label5.Text = "Mão";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(12, 325);
			label6.Name = "label6";
			label6.Size = new Size(53, 15);
			label6.TabIndex = 11;
			label6.Text = "baralho1";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(121, 325);
			label7.Name = "label7";
			label7.Size = new Size(53, 15);
			label7.TabIndex = 12;
			label7.Text = "baralho2";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(520, 325);
			label8.Name = "label8";
			label8.Size = new Size(53, 15);
			label8.TabIndex = 25;
			label8.Text = "baralho2";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(411, 325);
			label9.Name = "label9";
			label9.Size = new Size(53, 15);
			label9.TabIndex = 24;
			label9.Text = "baralho1";
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Location = new Point(411, 80);
			label10.Name = "label10";
			label10.Size = new Size(31, 15);
			label10.TabIndex = 23;
			label10.Text = "Mão";
			// 
			// radioButton3
			// 
			radioButton3.AutoSize = true;
			radioButton3.Location = new Point(411, 280);
			radioButton3.Name = "radioButton3";
			radioButton3.Size = new Size(94, 19);
			radioButton3.TabIndex = 22;
			radioButton3.TabStop = true;
			radioButton3.Text = "radioButton3";
			radioButton3.UseVisualStyleBackColor = true;
			// 
			// radioButton4
			// 
			radioButton4.AutoSize = true;
			radioButton4.Location = new Point(411, 255);
			radioButton4.Name = "radioButton4";
			radioButton4.Size = new Size(94, 19);
			radioButton4.TabIndex = 21;
			radioButton4.TabStop = true;
			radioButton4.Text = "radioButton4";
			radioButton4.UseVisualStyleBackColor = true;
			// 
			// checkedListBox5
			// 
			checkedListBox5.FormattingEnabled = true;
			checkedListBox5.Location = new Point(411, 185);
			checkedListBox5.Name = "checkedListBox5";
			checkedListBox5.Size = new Size(118, 22);
			checkedListBox5.TabIndex = 20;
			// 
			// checkedListBox6
			// 
			checkedListBox6.FormattingEnabled = true;
			checkedListBox6.Location = new Point(411, 157);
			checkedListBox6.Name = "checkedListBox6";
			checkedListBox6.Size = new Size(118, 22);
			checkedListBox6.TabIndex = 19;
			// 
			// checkedListBox7
			// 
			checkedListBox7.FormattingEnabled = true;
			checkedListBox7.Location = new Point(411, 129);
			checkedListBox7.Name = "checkedListBox7";
			checkedListBox7.Size = new Size(118, 22);
			checkedListBox7.TabIndex = 18;
			// 
			// checkedListBox8
			// 
			checkedListBox8.FormattingEnabled = true;
			checkedListBox8.Location = new Point(411, 101);
			checkedListBox8.Name = "checkedListBox8";
			checkedListBox8.Size = new Size(118, 22);
			checkedListBox8.TabIndex = 17;
			// 
			// label11
			// 
			label11.AutoSize = true;
			label11.Location = new Point(411, 65);
			label11.Name = "label11";
			label11.Size = new Size(40, 15);
			label11.TabIndex = 16;
			label11.Text = "Mana:";
			// 
			// label12
			// 
			label12.AutoSize = true;
			label12.Location = new Point(411, 50);
			label12.Name = "label12";
			label12.Size = new Size(26, 15);
			label12.TabIndex = 15;
			label12.Text = "HP:";
			// 
			// label13
			// 
			label13.AutoSize = true;
			label13.Location = new Point(411, 35);
			label13.Name = "label13";
			label13.Size = new Size(27, 15);
			label13.TabIndex = 14;
			label13.Text = "LvL:";
			// 
			// label14
			// 
			label14.AutoSize = true;
			label14.Location = new Point(411, 9);
			label14.Name = "label14";
			label14.Size = new Size(55, 15);
			label14.TabIndex = 13;
			label14.Text = "Jogador2";
			// 
			// button1
			// 
			button1.Location = new Point(254, 349);
			button1.Name = "button1";
			button1.Size = new Size(75, 23);
			button1.TabIndex = 26;
			button1.Text = "button1";
			button1.UseVisualStyleBackColor = true;
			// 
			// label15
			// 
			label15.AutoSize = true;
			label15.Location = new Point(264, 406);
			label15.Name = "label15";
			label15.Size = new Size(63, 15);
			label15.TabIndex = 27;
			label15.Text = "Problemas";
			// 
			// Jogo
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(label15);
			Controls.Add(button1);
			Controls.Add(label8);
			Controls.Add(label9);
			Controls.Add(label10);
			Controls.Add(radioButton3);
			Controls.Add(radioButton4);
			Controls.Add(checkedListBox5);
			Controls.Add(checkedListBox6);
			Controls.Add(checkedListBox7);
			Controls.Add(checkedListBox8);
			Controls.Add(label11);
			Controls.Add(label12);
			Controls.Add(label13);
			Controls.Add(label14);
			Controls.Add(label7);
			Controls.Add(label6);
			Controls.Add(label5);
			Controls.Add(radioButton2);
			Controls.Add(radioButton1);
			Controls.Add(checkedListBox4);
			Controls.Add(checkedListBox3);
			Controls.Add(checkedListBox2);
			Controls.Add(checkedListBox1);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "Jogo";
			Text = "Jogo";
			Load += Jogo_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private CheckedListBox checkedListBox1;
		private CheckedListBox checkedListBox2;
		private CheckedListBox checkedListBox3;
		private CheckedListBox checkedListBox4;
		private RadioButton radioButton1;
		private RadioButton radioButton2;
		private Label label5;
		private Label label6;
		private Label label7;
		private Label label8;
		private Label label9;
		private Label label10;
		private RadioButton radioButton3;
		private RadioButton radioButton4;
		private CheckedListBox checkedListBox5;
		private CheckedListBox checkedListBox6;
		private CheckedListBox checkedListBox7;
		private CheckedListBox checkedListBox8;
		private Label label11;
		private Label label12;
		private Label label13;
		private Label label14;
		private Button button1;
		private Label label15;
	}
}