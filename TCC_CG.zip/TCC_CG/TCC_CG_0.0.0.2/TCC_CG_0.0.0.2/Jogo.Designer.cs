﻿namespace TCC_CG_0._0._0._2
{
	partial class Jogo
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            button1 = new Button();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            button2 = new Button();
            button3 = new Button();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            label30 = new Label();
            lstHistorico = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(55, 15);
            label1.TabIndex = 0;
            label1.Text = "Jogador1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 35);
            label2.Name = "label2";
            label2.Size = new Size(27, 15);
            label2.TabIndex = 1;
            label2.Text = "LvL:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 50);
            label3.Name = "label3";
            label3.Size = new Size(26, 15);
            label3.TabIndex = 2;
            label3.Text = "HP:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 65);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 3;
            label4.Text = "Mana:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(36, 93);
            label5.Name = "label5";
            label5.Size = new Size(31, 15);
            label5.TabIndex = 10;
            label5.Text = "Mão";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 312);
            label6.Name = "label6";
            label6.Size = new Size(93, 15);
            label6.TabIndex = 11;
            label6.Text = "Pilha de compra";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 340);
            label7.Name = "label7";
            label7.Size = new Size(96, 15);
            label7.TabIndex = 12;
            label7.Text = "Pilha de descarte";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(348, 340);
            label8.Name = "label8";
            label8.Size = new Size(96, 15);
            label8.TabIndex = 25;
            label8.Text = "Pilha de descarte";
            label8.Click += label8_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(348, 312);
            label9.Name = "label9";
            label9.Size = new Size(93, 15);
            label9.TabIndex = 24;
            label9.Text = "Pilha de compra";
            label9.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(372, 93);
            label10.Name = "label10";
            label10.Size = new Size(31, 15);
            label10.TabIndex = 23;
            label10.Text = "Mão";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(348, 65);
            label11.Name = "label11";
            label11.Size = new Size(40, 15);
            label11.TabIndex = 16;
            label11.Text = "Mana:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(348, 50);
            label12.Name = "label12";
            label12.Size = new Size(26, 15);
            label12.TabIndex = 15;
            label12.Text = "HP:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(348, 35);
            label13.Name = "label13";
            label13.Size = new Size(27, 15);
            label13.TabIndex = 14;
            label13.Text = "LvL:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(348, 9);
            label14.Name = "label14";
            label14.Size = new Size(55, 15);
            label14.TabIndex = 13;
            label14.Text = "Jogador2";
            // 
            // button1
            // 
            button1.Location = new Point(625, 376);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 26;
            button1.Text = "Começa";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(589, 426);
            label15.Name = "label15";
            label15.Size = new Size(63, 15);
            label15.TabIndex = 27;
            label15.Text = "Problemas";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(14, 118);
            label16.Name = "label16";
            label16.Size = new Size(73, 15);
            label16.TabIndex = 28;
            label16.Text = "Mostra carta";
            label16.Click += label16_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(14, 146);
            label17.Name = "label17";
            label17.Size = new Size(73, 15);
            label17.TabIndex = 29;
            label17.Text = "Mostra carta";
            label17.Click += label17_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(14, 174);
            label18.Name = "label18";
            label18.Size = new Size(73, 15);
            label18.TabIndex = 30;
            label18.Text = "Mostra carta";
            label18.Click += label18_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(14, 202);
            label19.Name = "label19";
            label19.Size = new Size(73, 15);
            label19.TabIndex = 31;
            label19.Text = "Mostra carta";
            label19.Click += label19_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(348, 118);
            label20.Name = "label20";
            label20.Size = new Size(73, 15);
            label20.TabIndex = 34;
            label20.Text = "Mostra carta";
            label20.Click += label20_Click;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(348, 146);
            label21.Name = "label21";
            label21.Size = new Size(73, 15);
            label21.TabIndex = 35;
            label21.Text = "Mostra carta";
            label21.Click += label21_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(348, 174);
            label22.Name = "label22";
            label22.Size = new Size(73, 15);
            label22.TabIndex = 36;
            label22.Text = "Mostra carta";
            label22.Click += label22_Click;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(348, 202);
            label23.Name = "label23";
            label23.Size = new Size(73, 15);
            label23.TabIndex = 37;
            label23.Text = "Mostra carta";
            label23.Click += label23_Click;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(151, 93);
            label24.Name = "label24";
            label24.Size = new Size(72, 15);
            label24.TabIndex = 38;
            label24.Text = "Mostra ação";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(483, 93);
            label25.Name = "label25";
            label25.Size = new Size(72, 15);
            label25.TabIndex = 39;
            label25.Text = "Mostra ação";
            // 
            // button2
            // 
            button2.Location = new Point(12, 272);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 40;
            button2.Text = "Pronto";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(346, 272);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 41;
            button3.Text = "Pronto";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(151, 249);
            label26.Name = "label26";
            label26.Size = new Size(14, 15);
            label26.TabIndex = 42;
            label26.Text = "P";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(483, 249);
            label27.Name = "label27";
            label27.Size = new Size(14, 15);
            label27.TabIndex = 43;
            label27.Text = "P";
            label27.Click += label27_Click;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(707, 35);
            label28.Name = "label28";
            label28.Size = new Size(107, 15);
            label28.TabIndex = 44;
            label28.Text = "Historico de ações:";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(80, 50);
            label29.Name = "label29";
            label29.Size = new Size(28, 15);
            label29.TabIndex = 45;
            label29.Text = "Def:";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(417, 50);
            label30.Name = "label30";
            label30.Size = new Size(28, 15);
            label30.TabIndex = 46;
            label30.Text = "Def:";
            // 
            // lstHistorico
            // 
            lstHistorico.FormattingEnabled = true;
            lstHistorico.ItemHeight = 15;
            lstHistorico.Location = new Point(707, 53);
            lstHistorico.Name = "lstHistorico";
            lstHistorico.Size = new Size(239, 304);
            lstHistorico.TabIndex = 47;
            // 
            // Jogo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1028, 450);
            Controls.Add(lstHistorico);
            Controls.Add(label30);
            Controls.Add(label29);
            Controls.Add(label28);
            Controls.Add(label27);
            Controls.Add(label26);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(button1);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Jogo";
            Text = "Jogo";
            Load += Jogo_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private Label label5;
		private Label label6;
		private Label label7;
		private Label label8;
		private Label label9;
		private Label label10;
		private Label label11;
		private Label label12;
		private Label label13;
		private Label label14;
		private Button button1;
		private Label label15;
		private Label label16;
		private Label label17;
		private Label label18;
		private Label label19;
		private Label label20;
		private Label label21;
		private Label label22;
		private Label label23;
		private Label label24;
		private Label label25;
		private Button button2;
		private Button button3;
		private Label label26;
		private Label label27;
		private Label label28;
		private Label label29;
		private Label label30;
        private ListBox lstHistorico;
    }
}