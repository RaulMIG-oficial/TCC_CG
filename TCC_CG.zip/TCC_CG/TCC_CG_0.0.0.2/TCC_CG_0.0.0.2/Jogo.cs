﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC_CG_0._0._0._2
{
	internal partial class Jogo : Form
	{
		Jogador play1;
		Jogador play2;
		public Jogo(Jogador play1, Jogador play2)
		{
			InitializeComponent();
			this.play1 = play1;
			this.play2 = play2;
		}

		private void Jogo_Load(object sender, EventArgs e)
		{

		}
	}
}
