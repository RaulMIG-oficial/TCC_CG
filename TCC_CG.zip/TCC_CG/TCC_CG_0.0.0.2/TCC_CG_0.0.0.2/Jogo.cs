﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC_CG_0._0._0._2
{
	internal partial class Jogo : Form
	{
		Player play1;
		Player play2;
		bool preparado1 = false;
		bool preparado2 = false;
		List<bool> escCartas1 = new List<bool> { false, false, false, false };
		List<bool> escCartas2 = new List<bool> { false, false, false, false };
		Card1 card = new Card1();
		public Jogo(Jogador jogador1, Jogador jogador2)
		{
			InitializeComponent();
			play1 = new Player(jogador1, 1);
			play2 = new Player(jogador2, 2);
		}

		private void Jogo_Load(object sender, EventArgs e)
		{
			//
			// Play 1
			// 
			MostrarInfPlay(play1);
			MostrarInfPlay(play2);


		}
		public void MostrarInfPlay(Player play)
		{
			if (play.Id == 1)
			{
				label1.Text = play.jogador.Nome;
				label2.Text = "Lvl:" + Convert.ToString(play.jogador.lvl);
				label3.Text = "HP:" + Convert.ToString(play.jogador.HP);
				label4.Text = "Mana:" + Convert.ToString(play.jogador.Mana);
				label29.Text = "Def:" + Convert.ToString(play.def);
				label16.Text = play.NomeCarta(0);
				label17.Text = play.NomeCarta(1);
				label18.Text = play.NomeCarta(2);
				label19.Text = play.NomeCarta(3);
			}
			if (play.Id == 2)
			{
				label14.Text = play.jogador.Nome;
				label13.Text = "Lvl:" + Convert.ToString(play.jogador.lvl);
				label12.Text = "HP:" + Convert.ToString(play.jogador.HP);
				label11.Text = "Mana:" + Convert.ToString(play.jogador.Mana);
				label20.Text = play.NomeCarta(0);
				label21.Text = play.NomeCarta(1);
				label22.Text = play.NomeCarta(2);
				label23.Text = play.NomeCarta(3);
				label30.Text = "Def:" + Convert.ToString(play.def);
			}
			lstHistorico.Items.Add($"Alguma ação aconteceu para o {play.jogador.Nome}");
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (preparado1 == false)
			{
				button2.ForeColor = Color.Green;
				preparado1 = true;
			}
			else
			{
				button2.ForeColor = Color.Red;
				preparado1 = false;
			}

		}

		private void button3_Click(object sender, EventArgs e)
		{
			if (preparado2 == false)
			{
				button3.ForeColor = Color.Green;
				preparado2 = true;
			}
			else
			{
				button3.ForeColor = Color.Red;
				preparado2 = false;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if ((preparado1 == false) || (preparado2 == false))
			{
				label15.Text = "Os dois jogadores devem está prontos";
			}
			if ((preparado1 == true)&&(preparado2 == true))
			{
				Batalha(escCartas1, escCartas2, play1.Mao, play2.Mao);
			}
		}

		private void label16_Click(object sender, EventArgs e)
		{
			if (play1.jogador.Mana >= 1)
			{
				if (escCartas1[0] == false)
				{
					escCartas1[0] = true;
					play1.jogador.Mana--;
					label24.Text = label24.Text + "\n" + play1.LerDescCart(0, play1.Mao);
					label16.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas1[0] = false;
					play1.jogador.Mana++;
					label24.Text = "Mostra ação";
					label16.ForeColor = Color.Black;
				}
			}
			else if ((play1.jogador.Mana == 0) && (escCartas1[0] == true))
			{
				escCartas1[0] = false;
				play1.jogador.Mana++;
				label24.Text = "Mostra ação";
				label16.ForeColor = Color.Black;
			}
			label4.Text = "Mana:" + Convert.ToString(play1.jogador.Mana);
		}

		private void label17_Click(object sender, EventArgs e)
		{
			if (play1.jogador.Mana >= 1)
			{
				if (escCartas1[1] == false)
				{
					escCartas1[1] = true;
					play1.jogador.Mana--;
					label24.Text = label24.Text + "\n" + play1.LerDescCart(1, play1.Mao);
					label17.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas1[1] = false;
					play1.jogador.Mana++;
					label24.Text = "Mostra ação";
					label17.ForeColor = Color.Black;
				}
			}
			else if ((play1.jogador.Mana == 0) && (escCartas1[1] == true))
			{
				escCartas1[1] = false;
				play1.jogador.Mana++;
				label24.Text = "Mostra ação";
				label17.ForeColor = Color.Black;
			}
			label4.Text = "Mana:" + Convert.ToString(play1.jogador.Mana);
		}

		private void label18_Click(object sender, EventArgs e)
		{
			if (play1.jogador.Mana >= 1)
			{
				if (escCartas1[2] == false)
				{
					escCartas1[2] = true;
					play1.jogador.Mana--;
					label24.Text = label24.Text + "\n" + play1.LerDescCart(2, play1.Mao);
					label18.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas1[2] = false;
					play1.jogador.Mana++;
					label24.Text = "Mostra ação";
					label18.ForeColor = Color.Black;
				}
			}
			else if ((play1.jogador.Mana == 0) && (escCartas1[2] == true))
			{
				escCartas1[2] = false;
				play1.jogador.Mana++;
				label24.Text = "Mostra ação";
				label18.ForeColor = Color.Black;
			}
			label4.Text = "Mana:" + Convert.ToString(play1.jogador.Mana);
		}

		private void label19_Click(object sender, EventArgs e)
		{
			if (play1.jogador.Mana >= 1)
			{
				if (escCartas1[3] == false)
				{
					escCartas1[3] = true;
					play1.jogador.Mana--;
					label24.Text = label24.Text + "\n" + play1.LerDescCart(3, play1.Mao);
					label19.ForeColor = Color.LimeGreen;
				}

				else
				{
					escCartas1[3] = false;
					play1.jogador.Mana++;
					label24.Text = "Mostra ação";
					label19.ForeColor = Color.Black;
				}
			}
			else if ((play1.jogador.Mana == 0) && (escCartas1[3] == true))
			{
				escCartas1[3] = false;
				play1.jogador.Mana++;
				label24.Text = "Mostra ação";
				label19.ForeColor = Color.Black;
			}
			label4.Text = "Mana:" + Convert.ToString(play1.jogador.Mana);
		}

		private void label6_Click(object sender, EventArgs e)
		{
			label26.Text = "";
			label26.Text = play1.LerPilha(play1.pilha_compra);

		}

		private void label7_Click(object sender, EventArgs e)
		{
			label26.Text = "";
			label26.Text = play1.LerPilha(play1.baralho);
		}

		private void label20_Click(object sender, EventArgs e)
		{
			if (play2.jogador.Mana >= 1)
			{
				if (escCartas2[0] == false)
				{
					escCartas2[0] = true;
					play2.jogador.Mana--;
					label25.Text = label25.Text + "\n" + play2.LerDescCart(0, play2.Mao);
					label20.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas2[0] = false;
					play2.jogador.Mana++;
					label25.Text = "Mostra ação";
					label20.ForeColor = Color.Black;
				}
			}
			else if ((play2.jogador.Mana == 0) && (escCartas2[0] == true))
			{
				escCartas2[0] = false;
				play2.jogador.Mana++;
				label25.Text = "Mostra ação";
				label20.ForeColor = Color.Black;
			}
			label11.Text = "Mana:" + Convert.ToString(play2.jogador.Mana);
		}

		private void label21_Click(object sender, EventArgs e)
		{
			if (play2.jogador.Mana >= 1)
			{
				if (escCartas2[1] == false)
				{
					escCartas2[1] = true;
					play2.jogador.Mana--;
					label25.Text = label25.Text + "\n" + play2.LerDescCart(1, play2.Mao);
					label21.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas2[1] = false;
					play2.jogador.Mana++;
					label25.Text = "Mostra ação";
					label21.ForeColor = Color.Black;
				}
			}
			else if ((play2.jogador.Mana == 0) && (escCartas2[1] == true))
			{
				escCartas2[0] = false;
				play2.jogador.Mana++;
				label25.Text = "Mostra ação";
				label21.ForeColor = Color.Black;
			}
			label11.Text = "Mana:" + Convert.ToString(play2.jogador.Mana);
		}

		private void label22_Click(object sender, EventArgs e)
		{
			if (play2.jogador.Mana >= 1)
			{
				if (escCartas2[2] == false)
				{
					escCartas2[2] = true;
					play2.jogador.Mana--;
					label25.Text = label25.Text + "\n" + play2.LerDescCart(2, play2.Mao);
					label22.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas2[2] = false;
					play2.jogador.Mana++;
					label25.Text = "Mostra ação";
					label22.ForeColor = Color.Black;
				}
			}
			else if ((play2.jogador.Mana == 0) && (escCartas2[2] == true))
			{
				escCartas2[2] = false;
				play2.jogador.Mana++;
				label25.Text = "Mostra ação";
				label22.ForeColor = Color.Black;
			}
			label11.Text = "Mana:" + Convert.ToString(play2.jogador.Mana);
		}

		private void label23_Click(object sender, EventArgs e)
		{
			if (play2.jogador.Mana >= 1)
			{
				if (escCartas2[3] == false)
				{
					escCartas2[3] = true;
					play2.jogador.Mana--;
					label25.Text = label25.Text + "\n" + play2.LerDescCart(3, play2.Mao);
					label23.ForeColor = Color.LimeGreen;
				}
				else
				{
					escCartas2[3] = false;
					play2.jogador.Mana++;
					label25.Text = "Mostra ação";
					label23.ForeColor = Color.Black;
				}
			}
			else if ((play2.jogador.Mana == 0) && (escCartas2[3] == true))
			{
				escCartas2[3] = false;
				play2.jogador.Mana++;
				label25.Text = "Mostra ação";
				label23.ForeColor = Color.Black;
			}
			label11.Text = "Mana:" + Convert.ToString(play2.jogador.Mana);
		}

		private void label9_Click(object sender, EventArgs e)
		{
			label27.Text = "";
			label27.Text = play2.LerPilha(play2.pilha_compra);
		}
		private void label27_Click(object sender, EventArgs e)
		{

		}

		private void label8_Click(object sender, EventArgs e)
		{
			label27.Text = "";
			label27.Text = play2.LerPilha(play2.pilha_descarte);
		}
		public async void Batalha(List<bool> C1, List<bool> C2, List<string> M1, List<string> M2)
		{
			for (int i = 0; i < 3; i++)
			{
				if (C1[i] == true)
				{
					card = play1.Effeito(M1[i]);
					if (play2.def >= card.Dano)//D
					{
						play2.def = play2.def - card.Dano;
					}
					else if (play2.def < card.Dano)//D
					{
						play2.def = play2.def - card.Dano;
						play2.jogador.HP = play2.jogador.HP + play2.def;
					}
					if (play1.jogador.HP < play1.jogador.HP_Base)//C
					{
						play1.jogador.HP += card.Cura;
						if (play1.jogador.HP > play1.jogador.HP_Base)
						{
							play1.jogador.HP = play1.jogador.HP_Base;
						}
					}
					play1.def += card.Defesa;
					
				}
				MostrarInfPlay(play1);
				MostrarInfPlay(play2);

				await Task.Delay(3000);

				if (C2[i] == true)
				{
					card = play2.Effeito(M1[i]);
					if (play1.def >= card.Dano)
					{
						play1.def = play1.def - card.Dano;
					}
					else if (play1.def < card.Dano)
					{
						play1.def = play1.def - card.Dano;
						play1.jogador.HP = play1.jogador.HP + play1.def;
					}
					
					if (play2.jogador.HP < play2.jogador.HP_Base)
					{
						play2.jogador.HP += card.Cura;
						if (play2.jogador.HP > play2.jogador.HP_Base)
						{
							play2.jogador.HP = play2.jogador.HP_Base;
						}
					}
					play2.def += card.Defesa;
				}
				MostrarInfPlay(play1);
				MostrarInfPlay(play2);

				await Task.Delay(3000);

			}
			play1.PuxarMao();
			play2.PuxarMao();
			play1.pilha_descarte.Add(play1.Mao[0]);
			play1.pilha_descarte.Add(play1.Mao[1]);
			play1.pilha_descarte.Add(play1.Mao[2]);
			play1.pilha_descarte.Add(play1.Mao[3]);
			play1.Mao.Clear();
			play2.pilha_descarte.Add(play2.Mao[0]);
			play2.pilha_descarte.Add(play2.Mao[1]);
			play2.pilha_descarte.Add(play2.Mao[2]);
			play2.pilha_descarte.Add(play2.Mao[3]);
			play2.Mao.Clear();
			
		}
	}
}
