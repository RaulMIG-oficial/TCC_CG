﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace TCC_CG_0._0._0._2
{
	internal class Player
	{
		public int Id = 0;
		public Jogador jogador = null;
		public List<string> baralho = new List<string>();
		public List<string> pilha_compra = new List<string>();
		public List<string> pilha_descarte = new List<string>();
		public List<string> Mao = new List<string>();
		public int def = 0;

		public Player(Jogador jogador, int id)
		{
			Id = id;
			this.jogador = jogador;
			string[] Cartas = this.jogador.BaralhoBase.ToString().Split(',');
			for (int i = 0; i < Cartas.Length; i++)
			{
				baralho.Add(Cartas[i]);
				pilha_compra.Add(Cartas[i]);
			}
			PuxarMao();
			
			
		}
		public void PuxarMao()
		{
			Random random = new Random();
			int cartaM1;
			for(int i = 4;Mao.Count < i; i = i)
			{ 
				if(pilha_compra.Count >= 1)
				{
					cartaM1 = random.Next(1, pilha_compra.Count);
					Mao.Add(pilha_compra[cartaM1]);
					pilha_compra.RemoveAt(cartaM1 - 1);

				}
				else
				{
					pilha_compra = pilha_descarte;
					pilha_descarte.Clear();
				}
			}
		}
		public string NomeCarta(int num)
		{
			string nome = "erro";
			using (var connection = new MySqlConnection(CodBD.connection))
			{
				connection.Open();
				string query = "SELECT nome_carta FROM cartas WHERE id_carta = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", Mao[num]);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{

							nome = reader.GetString("nome_carta");
								
						}
					}
				}
			}
			return nome;
		}
		public string LerDescCart(int num,List<string> a)
		{
			if (a[num] == "1")
			{
				string descricao = "Cause 6 de dano no oponente";
				return descricao;
			}
			else if (a[num] == "2")
			{
				string descricao = "Aplique 5 de Amadura em você";
				return descricao;
			}
			else if (a[num] == "3")
			{
				string descricao = "Cure 4 pontos de HP";
				return descricao;
			}
			else
			{
				string descricao = "erro";
				return descricao;
			}
		}
		public string LerPilha(List<string> pilha)
		{
			string text = null;
			for (int i = 0; i < pilha.Count; i++)
			{
				string a = LerDescCart(Convert.ToInt32(pilha[i]),pilha);
				text = text + "\n" + a;
			}
			return text;
		}
		public Card1 Effeito(string a)
		{
			Card1 card1 = new Card1();
			Card1Repository card1repo = new Card1Repository(CodBD.connection);
			return card1 = card1repo.ObterCartaPeloId(Convert.ToInt32(a));
		}
	}
}
