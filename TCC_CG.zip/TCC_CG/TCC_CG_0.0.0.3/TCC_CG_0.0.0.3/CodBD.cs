﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._3
{
	internal class CodBD
	{
		public string email_usuario = null;
		public static string connection { get; } = "server=br60.hostgator.com.br;database=joaola59_card_raul;uid=joaola59_usu_card_raul;pwd=h68Dw+h!Ks!Y;";
		public CodBD(string email)
		{
			email_usuario = email;
		}
	}
}
