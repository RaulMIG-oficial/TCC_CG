﻿namespace TCC_CG_0._0._0._3
{
    partial class Logar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			textBox2 = new TextBox();
			label3 = new Label();
			textBox1 = new TextBox();
			label2 = new Label();
			button4 = new Button();
			label4 = new Label();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(20, 30);
			label1.Name = "label1";
			label1.Size = new Size(93, 15);
			label1.TabIndex = 2;
			label1.Text = "ParanormalCard";
			label1.Click += label1_Click;
			// 
			// textBox2
			// 
			textBox2.Location = new Point(126, 106);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(169, 23);
			textBox2.TabIndex = 11;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(20, 109);
			label3.Name = "label3";
			label3.Size = new Size(45, 15);
			label3.TabIndex = 10;
			label3.Text = "Senha :";
			// 
			// textBox1
			// 
			textBox1.Location = new Point(126, 77);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(169, 23);
			textBox1.TabIndex = 9;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(20, 80);
			label2.Name = "label2";
			label2.Size = new Size(54, 15);
			label2.TabIndex = 8;
			label2.Text = "Apelido :";
			// 
			// button4
			// 
			button4.Location = new Point(20, 166);
			button4.Name = "button4";
			button4.Size = new Size(93, 36);
			button4.TabIndex = 19;
			button4.Text = "Proseguir";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(140, 177);
			label4.Name = "label4";
			label4.Size = new Size(45, 15);
			label4.TabIndex = 20;
			label4.Text = "Senha :";
			// 
			// Logar
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(344, 231);
			Controls.Add(label4);
			Controls.Add(button4);
			Controls.Add(textBox2);
			Controls.Add(label3);
			Controls.Add(textBox1);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "Logar";
			Text = "Logar";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox1;
        private Label label2;
        private Button button4;
		private Label label4;
	}
}