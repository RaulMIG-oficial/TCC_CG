﻿namespace TCC_CG_0._0._0._3
{
    partial class MenuDoJogador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			label1 = new Label();
			button1 = new Button();
			button2 = new Button();
			button3 = new Button();
			button4 = new Button();
			button5 = new Button();
			button6 = new Button();
			label2 = new Label();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(20, 30);
			label1.Name = "label1";
			label1.Size = new Size(93, 15);
			label1.TabIndex = 1;
			label1.Text = "ParanormalCard";
			label1.Click += label1_Click;
			// 
			// button1
			// 
			button1.Location = new Point(1, 387);
			button1.Name = "button1";
			button1.Size = new Size(140, 63);
			button1.TabIndex = 2;
			button1.Text = "Mochila";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// button2
			// 
			button2.Location = new Point(147, 387);
			button2.Name = "button2";
			button2.Size = new Size(140, 63);
			button2.TabIndex = 3;
			button2.Text = "Loja";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// button3
			// 
			button3.Location = new Point(293, 387);
			button3.Name = "button3";
			button3.Size = new Size(140, 63);
			button3.TabIndex = 4;
			button3.Text = "Iniciar partida";
			button3.UseVisualStyleBackColor = true;
			button3.Click += button3_Click;
			// 
			// button4
			// 
			button4.Location = new Point(439, 387);
			button4.Name = "button4";
			button4.Size = new Size(140, 63);
			button4.TabIndex = 5;
			button4.Text = "Gacha";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// button5
			// 
			button5.Location = new Point(585, 387);
			button5.Name = "button5";
			button5.Size = new Size(140, 63);
			button5.TabIndex = 6;
			button5.Text = "null";
			button5.UseVisualStyleBackColor = true;
			// 
			// button6
			// 
			button6.Location = new Point(147, 227);
			button6.Name = "button6";
			button6.Size = new Size(140, 63);
			button6.TabIndex = 7;
			button6.Text = "JOGAR";
			button6.UseVisualStyleBackColor = true;
			button6.Click += button6_Click_1;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(324, 251);
			label2.Name = "label2";
			label2.Size = new Size(38, 15);
			label2.TabIndex = 8;
			label2.Text = "label2";
			// 
			// MenuDoJogador
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(728, 450);
			Controls.Add(label2);
			Controls.Add(button6);
			Controls.Add(button5);
			Controls.Add(button4);
			Controls.Add(button3);
			Controls.Add(button2);
			Controls.Add(button1);
			Controls.Add(label1);
			Name = "MenuDoJogador";
			Text = "MenuDoJogador";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
		public System.ComponentModel.BackgroundWorker backgroundWorker1;
		private Button button6;
		private Label label2;
	}
}