﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._3.Objetos
{
    internal class Baralho
    {
		public int Id { get; set; }
		public string Cartas { get; set; }

	}
}
