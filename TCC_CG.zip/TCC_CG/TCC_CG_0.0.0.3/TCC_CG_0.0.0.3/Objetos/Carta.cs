﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._3.Objetos
{
    internal class Carta
    {
		public string Nome { get; set; }
		public int Dano { get; set; }
		public int Defesa { get; set; }
		public int Cura { get; set; }
		public int Id { get; set; }
	}
}
