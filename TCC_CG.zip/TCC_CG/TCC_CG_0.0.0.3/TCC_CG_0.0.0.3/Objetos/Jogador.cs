﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._3.Objetos
{
    internal class Jogador
    {
		public int Id { get; set; }
		public string Nome { get; set; }
		public string Senha { get; set; }
		public string BaralhoBase { get; set; }

		public Baralho BaralhoJogo { get; set; }

		public string BaralhoGlobal { get; set; }
		public int Win = 0;
		public int Lose = 0;
		public int lvl = 1;
		public int HP_Base = 20;
		public int HP = 20;
		public int Mana = 3;

	}
}
