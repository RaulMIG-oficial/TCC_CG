﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;

namespace TCC_CG_0._0._0._3.Repository
{
    internal class BaralhoRepository
    {
		private readonly string _connectionString;

		public BaralhoRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		public Baralho ObterBaralhoBasePorId(int IdBaralho)
		{
			Baralho baralho = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT id_baralho, id_cartas_string FROM baralho_base WHERE id_baralho = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", IdBaralho);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							baralho = new Baralho
							{
								Id = IdBaralho,
								Cartas = reader.GetString("id_cartas_string")
							};
						}
					}
				}
			}
			return baralho;
		}
		public Baralho ObterBaralhoGlobalPorId(int IdBaralho)
		{
			Baralho baralho = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT id_baralho, id_cartas_string FROM baralho_global WHERE id_baralho = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", IdBaralho);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							baralho = new Baralho
							{
								Id = IdBaralho,
								Cartas = reader.GetString("id_cartas_string")
							};
						}
					}
				}
			}
			return baralho;
		}
	}
}
