-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 14/07/2025 às 10:21
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc_card_gamer0.0.0.2`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `baralho_base`
--

CREATE TABLE `baralho_base` (
  `id_baralho` int(11) NOT NULL,
  `id_cartas_string` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `baralho_base`
--

INSERT INTO `baralho_base` (`id_baralho`, `id_cartas_string`) VALUES
(1, '1,1,1,1,1,2,2,2,2,3,3'),
(2, '1,1,1,1,2,2,2,2,2,3,3'),
(3, '1,1,1,2,2,2,2,2,3,3,3');

-- --------------------------------------------------------

--
-- Estrutura para tabela `baralho_global`
--

CREATE TABLE `baralho_global` (
  `id_baralho` int(11) NOT NULL,
  `id_cartas_string` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `baralho_global`
--

INSERT INTO `baralho_global` (`id_baralho`, `id_cartas_string`) VALUES
(1, '1,1,1,1,1,2,2,2,2,3,3'),
(2, '1,1,1,1,2,2,2,2,2,3,3'),
(3, '1,1,1,1,2,2,2,2,3,3,3');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cartas`
--

CREATE TABLE `cartas` (
  `id_carta` int(11) NOT NULL,
  `dano` int(2) NOT NULL,
  `defesa` int(2) NOT NULL,
  `regeneração` int(2) NOT NULL,
  `nome_carta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cartas`
--

INSERT INTO `cartas` (`id_carta`, `dano`, `defesa`, `regeneração`, `nome_carta`) VALUES
(1, 6, 0, 0, 'Golpe'),
(2, 0, 5, 0, 'Defender'),
(3, 0, 0, 4, 'Curar');

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogador`
--

CREATE TABLE `jogador` (
  `id_usuario` int(11) NOT NULL,
  `nome_usuario` varchar(20) NOT NULL,
  `lvl` int(2) NOT NULL DEFAULT 1,
  `senha` text NOT NULL,
  `id_baralho_base` int(11) NOT NULL,
  `id_baralho_global` int(11) NOT NULL,
  `Win` int(11) NOT NULL DEFAULT 0,
  `Lose` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogador`
--

INSERT INTO `jogador` (`id_usuario`, `nome_usuario`, `lvl`, `senha`, `id_baralho_base`, `id_baralho_global`, `Win`, `Lose`) VALUES
(14, 'RaulMIG', 1, 'ng7Jf+fzP2GsyfPTPxgXDGITI5FnaHFujJRr+BXQDF4=', 1, 1, 0, 0),
(15, 'JoãoTBI', 1, 'PEjdIDjwJh5lmnuauUNxPDAS0KUEiAHvHr6f0W0AT2Y=', 2, 2, 0, 0),
(16, 'BatataGamer', 1, 'twOyUR9kerte/UiQpqUaA9SFiKduNYUE8mS1d840FH8=', 3, 3, 0, 0),
(17, 'BatataGamer', 1, 'twOyUR9kerte/UiQpqUaA9SFiKduNYUE8mS1d840FH8=', 3, 3, 0, 0),
(18, 'LyanMC', 1, 'n9RO50Vqwv7tK/2+C3oqV95hbc65sAdBwgNrYbC8uP0=', 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `lvl`
--

CREATE TABLE `lvl` (
  `nivel_lvl` int(2) NOT NULL,
  `hp_base` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `lvl`
--

INSERT INTO `lvl` (`nivel_lvl`, `hp_base`) VALUES
(1, 20),
(2, 24),
(3, 28),
(4, 32),
(5, 36);

-- --------------------------------------------------------

--
-- Estrutura para tabela `partidas`
--

CREATE TABLE `partidas` (
  `id_partida` int(11) NOT NULL,
  `id_jogador_1` int(11) NOT NULL,
  `id_jogador_2` int(11) NOT NULL,
  `id_jogador_Win` int(11) NOT NULL,
  `id_jogador_Lose` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `baralho_base`
--
ALTER TABLE `baralho_base`
  ADD PRIMARY KEY (`id_baralho`);

--
-- Índices de tabela `baralho_global`
--
ALTER TABLE `baralho_global`
  ADD PRIMARY KEY (`id_baralho`);

--
-- Índices de tabela `cartas`
--
ALTER TABLE `cartas`
  ADD PRIMARY KEY (`id_carta`);

--
-- Índices de tabela `jogador`
--
ALTER TABLE `jogador`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `Jogador_lvl_lvl_nivel_lvl` (`lvl`),
  ADD KEY `Jogador_id_baralho_base_Baralho_base_id_baralho` (`id_baralho_base`),
  ADD KEY `Jogador_id_baralho_global_baralho_global_id_baralho` (`id_baralho_global`);

--
-- Índices de tabela `lvl`
--
ALTER TABLE `lvl`
  ADD PRIMARY KEY (`nivel_lvl`);

--
-- Índices de tabela `partidas`
--
ALTER TABLE `partidas`
  ADD PRIMARY KEY (`id_partida`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `baralho_base`
--
ALTER TABLE `baralho_base`
  MODIFY `id_baralho` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `baralho_global`
--
ALTER TABLE `baralho_global`
  MODIFY `id_baralho` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `cartas`
--
ALTER TABLE `cartas`
  MODIFY `id_carta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `jogador`
--
ALTER TABLE `jogador`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `partidas`
--
ALTER TABLE `partidas`
  MODIFY `id_partida` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `jogador`
--
ALTER TABLE `jogador`
  ADD CONSTRAINT `Jogador_id_baralho_base_Baralho_base_id_baralho` FOREIGN KEY (`id_baralho_base`) REFERENCES `baralho_base` (`id_baralho`),
  ADD CONSTRAINT `Jogador_id_baralho_global_baralho_global_id_baralho` FOREIGN KEY (`id_baralho_global`) REFERENCES `baralho_global` (`id_baralho`),
  ADD CONSTRAINT `Jogador_lvl_lvl_nivel_lvl` FOREIGN KEY (`lvl`) REFERENCES `lvl` (`nivel_lvl`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
