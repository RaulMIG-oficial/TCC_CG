﻿namespace TCC_CG_0._0._0._3
{
    partial class CriarConta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			label2 = new Label();
			textBox1 = new TextBox();
			textBox2 = new TextBox();
			label3 = new Label();
			textBox3 = new TextBox();
			label4 = new Label();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			label8 = new Label();
			label9 = new Label();
			label10 = new Label();
			label11 = new Label();
			button1 = new Button();
			button2 = new Button();
			button3 = new Button();
			button4 = new Button();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(20, 30);
			label1.Name = "label1";
			label1.Size = new Size(93, 15);
			label1.TabIndex = 1;
			label1.Text = "ParanormalCard";
			label1.Click += label1_Click;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(20, 72);
			label2.Name = "label2";
			label2.Size = new Size(54, 15);
			label2.TabIndex = 2;
			label2.Text = "Apelido :";
			// 
			// textBox1
			// 
			textBox1.Location = new Point(126, 69);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(169, 23);
			textBox1.TabIndex = 3;
			// 
			// textBox2
			// 
			textBox2.Location = new Point(126, 98);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(169, 23);
			textBox2.TabIndex = 5;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(20, 101);
			label3.Name = "label3";
			label3.Size = new Size(45, 15);
			label3.TabIndex = 4;
			label3.Text = "Senha :";
			// 
			// textBox3
			// 
			textBox3.Location = new Point(126, 127);
			textBox3.Name = "textBox3";
			textBox3.Size = new Size(169, 23);
			textBox3.TabIndex = 7;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(20, 130);
			label4.Name = "label4";
			label4.Size = new Size(102, 15);
			label4.TabIndex = 6;
			label4.Text = "Confirmar Senha :";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(20, 168);
			label5.Name = "label5";
			label5.Size = new Size(145, 15);
			label5.TabIndex = 8;
			label5.Text = "Escolha seu baralho inicial";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(20, 206);
			label6.Name = "label6";
			label6.Size = new Size(119, 15);
			label6.TabIndex = 9;
			label6.Text = "Deck do Combatente";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(176, 206);
			label7.Name = "label7";
			label7.Size = new Size(100, 15);
			label7.TabIndex = 10;
			label7.Text = "Deck do Defensor";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(331, 206);
			label8.Name = "label8";
			label8.Size = new Size(96, 15);
			label8.TabIndex = 11;
			label8.Text = "Deck do Protetor";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(331, 248);
			label9.Name = "label9";
			label9.Size = new Size(103, 45);
			label9.TabIndex = 14;
			label9.Text = "3 Cartas de Corte\r\n4 Cartas de Defesa\r\n3 Cartas de cura\r\n";
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Location = new Point(176, 248);
			label10.Name = "label10";
			label10.Size = new Size(103, 45);
			label10.TabIndex = 13;
			label10.Text = "4 Cartas de Corte\r\n4 Cartas de Defesa\r\n2 Cartas de cura";
			label10.Click += label10_Click;
			// 
			// label11
			// 
			label11.AutoSize = true;
			label11.Location = new Point(20, 248);
			label11.Name = "label11";
			label11.Size = new Size(103, 45);
			label11.TabIndex = 12;
			label11.Text = "5 Cartas de Corte\r\n3 Cartas de Defesa\r\n2 Cartas de Cura";
			// 
			// button1
			// 
			button1.Location = new Point(29, 332);
			button1.Name = "button1";
			button1.Size = new Size(91, 23);
			button1.TabIndex = 15;
			button1.Text = "Combatente";
			button1.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			button2.Location = new Point(176, 332);
			button2.Name = "button2";
			button2.Size = new Size(91, 23);
			button2.TabIndex = 16;
			button2.Text = "Defensor";
			button2.UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			button3.Location = new Point(334, 332);
			button3.Name = "button3";
			button3.Size = new Size(91, 23);
			button3.TabIndex = 17;
			button3.Text = "Protetor";
			button3.UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			button4.Location = new Point(20, 424);
			button4.Name = "button4";
			button4.Size = new Size(75, 23);
			button4.TabIndex = 18;
			button4.Text = "Finalizar";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// CriarConta
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(484, 521);
			Controls.Add(button4);
			Controls.Add(button3);
			Controls.Add(button2);
			Controls.Add(button1);
			Controls.Add(label9);
			Controls.Add(label10);
			Controls.Add(label11);
			Controls.Add(label8);
			Controls.Add(label7);
			Controls.Add(label6);
			Controls.Add(label5);
			Controls.Add(textBox3);
			Controls.Add(label4);
			Controls.Add(textBox2);
			Controls.Add(label3);
			Controls.Add(textBox1);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "CriarConta";
			Text = "CriarConta";
			Load += CriarConta_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
	}
}