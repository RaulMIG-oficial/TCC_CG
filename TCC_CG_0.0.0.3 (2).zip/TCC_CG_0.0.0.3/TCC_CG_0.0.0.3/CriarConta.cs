﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC_CG_0._0._0._3
{
	public partial class CriarConta : Form
	{
		public CriarConta()
		{
			InitializeComponent();
		}

		private void label1_Click(object sender, EventArgs e)
		{
			this.Hide();
		}

		private void label10_Click(object sender, EventArgs e)
		{

		}

		private void CriarConta_Load(object sender, EventArgs e)
		{

		}

		private void button4_Click(object sender, EventArgs e)
		{

		}
	}
}
