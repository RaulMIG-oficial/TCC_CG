﻿namespace TCC_CG_0._0._0._3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   //
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			panel1 = new Panel();
			button4 = new Button();
			textBox2 = new TextBox();
			textBox1 = new TextBox();
			panel2 = new Panel();
			panel1.SuspendLayout();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.BackColor = Color.Transparent;
			label1.Font = new Font("Segoe UI", 32F);
			label1.Location = new Point(12, 9);
			label1.Name = "label1";
			label1.Size = new Size(374, 59);
			label1.TabIndex = 0;
			label1.Text = "Indies Card Gamer";
			label1.Click += label1_Click;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.BackColor = Color.Transparent;
			label2.Font = new Font("Segoe UI", 16F);
			label2.Location = new Point(12, 240);
			label2.Name = "label2";
			label2.Size = new Size(91, 30);
			label2.TabIndex = 1;
			label2.Text = "► Jogar";
			label2.Click += label2_Click;
			label2.MouseEnter += label2_MouseEnter;
			label2.MouseLeave += label2_MouseLeave;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.BackColor = Color.Transparent;
			label3.Font = new Font("Segoe UI", 16F);
			label3.Location = new Point(12, 270);
			label3.Name = "label3";
			label3.Size = new Size(177, 30);
			label3.TabIndex = 2;
			label3.Text = "► Configurações";
			label3.Click += label3_Click;
			label3.MouseEnter += label3_MouseEnter;
			label3.MouseLeave += label3_MouseLeave;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.BackColor = Color.Transparent;
			label4.Font = new Font("Segoe UI", 16F);
			label4.Location = new Point(12, 300);
			label4.Name = "label4";
			label4.Size = new Size(143, 30);
			label4.TabIndex = 3;
			label4.Text = "► Criar conta";
			label4.Click += label4_Click;
			label4.MouseEnter += label4_MouseEnter;
			label4.MouseLeave += label4_MouseLeave;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Font = new Font("Segoe UI", 12F);
			label5.Location = new Point(37, 241);
			label5.Name = "label5";
			label5.Size = new Size(39, 21);
			label5.TabIndex = 26;
			label5.Text = "Erro";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Font = new Font("Segoe UI", 12F);
			label6.Location = new Point(37, 94);
			label6.Name = "label6";
			label6.Size = new Size(60, 21);
			label6.TabIndex = 23;
			label6.Text = "Senha :";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Font = new Font("Segoe UI", 12F);
			label7.Location = new Point(37, 46);
			label7.Name = "label7";
			label7.Size = new Size(70, 21);
			label7.TabIndex = 21;
			label7.Text = "Apelido :";
			// 
			// panel1
			// 
			panel1.BackColor = SystemColors.ButtonShadow;
			panel1.Controls.Add(label5);
			panel1.Controls.Add(button4);
			panel1.Controls.Add(textBox2);
			panel1.Controls.Add(label6);
			panel1.Controls.Add(textBox1);
			panel1.Controls.Add(label7);
			panel1.Location = new Point(212, 140);
			panel1.Name = "panel1";
			panel1.Size = new Size(720, 360);
			panel1.TabIndex = 5;
			// 
			// button4
			// 
			button4.Font = new Font("Segoe UI", 12F);
			button4.Location = new Point(37, 303);
			button4.Name = "button4";
			button4.Size = new Size(171, 36);
			button4.TabIndex = 25;
			button4.Text = "Proseguir";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// textBox2
			// 
			textBox2.Font = new Font("Segoe UI", 12F);
			textBox2.Location = new Point(113, 91);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(195, 29);
			textBox2.TabIndex = 24;
			// 
			// textBox1
			// 
			textBox1.Font = new Font("Segoe UI", 12F);
			textBox1.Location = new Point(113, 43);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(195, 29);
			textBox1.TabIndex = 22;
			// 
			// panel2
			// 
			panel2.BackColor = SystemColors.ControlDarkDark;
			panel2.Location = new Point(212, 540);
			panel2.Name = "panel2";
			panel2.Size = new Size(720, 360);
			panel2.TabIndex = 6;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.Control;
			BackgroundImageLayout = ImageLayout.Stretch;
			ClientSize = new Size(944, 501);
			Controls.Add(panel2);
			Controls.Add(panel1);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "Form1";
			Text = "Form1";
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
		private Panel panel1;
		private Panel panel2;
		private Label label5;
		private Button button4;
		private TextBox textBox2;
		private Label label6;
		private TextBox textBox1;
		private Label label7;
	}
}
