using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;

namespace TCC_CG_0._0._0._3
{
	internal partial class Form1 : Form
	{
		private bool painelLogin = false; // var para ver se o painel de Login est� ativo
		private bool painelConfiguracoes = false; // var para ver se o painel de Configura��es est� ativo
		private bool label2click = false; // vari para ver se a label2 est� ativa
		private bool label3click = false; // vari para ver se a label3 est� ativa
		public Form1()
		{
			InitializeComponent();
			ImagemFundoMenu();
		}
		//
		// *** button ***
		//
		private void button1_Click(object sender, EventArgs e)
		{
			Logar login = new Logar();
			this.Hide();
			login.ShowDialog();
			this.Show();
		}
		private void button4_Click(object sender, EventArgs e)
		{
			string nome = textBox1.Text;
			string senha = textBox2.Text;
			string senhaHash = Cripto_Hash.GerarHashSha256(senha);
			JogadorRepository repo = new JogadorRepository(CodBD.connection);
			if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(senha))
			{
				label5.Text = "> Erro: Preencha todos os campos";
				return;
			}
			Jogador player = repo.ObterPorNomeESenha(nome, senhaHash);
			if (player != null)
			{
				MenuDoJogador Menu = new MenuDoJogador(player);
				this.Hide();
				Menu.ShowDialog();
				this.Show();
			}
		}
		//
		// *** label ***
		//
		private async void label2_MouseEnter(object sender, EventArgs e)
		{
			if (label2click == false)
			{
				label2.ForeColor = Color.Aqua;
				int Py = 240;
				int Px = 12;
				for (int i = Px; i < 22; i++)
				{
					label2.Location = new Point(i, Py);
					await Task.Delay(2);
				}
			}
			else
			{
				label2.ForeColor = Color.Aqua;
			}
		}
		private async void label2_MouseLeave(object sender, EventArgs e)
		{
			if (label2click == false)
			{
				label2.ForeColor = Color.Black;
				int Py = 240;
				int Px = 22;
				for (int i = Px; i > 12; i--)
				{
					label2.Location = new Point(i, Py);
					await Task.Delay(1);
				}
			}
			else
			{
				label2.ForeColor = Color.Aqua;
			}
		}
		private async void label3_MouseEnter(object sender, EventArgs e)
		{
			if (label3click == false)
			{
				label3.ForeColor = Color.Aqua;
				int Py = 270;
				int Px = 12;
				for (int i = Px; i < 22; i++)
				{
					label3.Location = new Point(i, Py);
					await Task.Delay(1);
				}
			}
			else
			{
				label3.ForeColor = Color.Aqua;
			}
		}
		private async void label3_MouseLeave(object sender, EventArgs e)
		{
			if (label3click == false)
			{
				label3.ForeColor = Color.Black;
				int Py = 270;
				int Px = 22;
				for (int i = Px; i > 12; i--)
				{
					label3.Location = new Point(i, Py);
					await Task.Delay(1);
				}
			}
			else
			{
				label3.ForeColor = Color.Aqua;
			}
		}
		private async void label4_MouseEnter(object sender, EventArgs e)
		{
			label4.ForeColor = Color.Aqua;
			int Py = 300;
			int Px = 12;
			for (int i = Px; i < 22; i++)
			{
				label4.Location = new Point(i, Py);
				await Task.Delay(1);
			}
		}
		private async void label4_MouseLeave(object sender, EventArgs e)
		{
			label4.ForeColor = Color.Black;
			int Py = 300;
			int Px = 22;
			for (int i = Px; i > 12; i--)
			{
				label4.Location = new Point(i, Py);
				await Task.Delay(2);
			}
		}
		private void label1_Click(object sender, EventArgs e)
		{

		}
		private async void label2_Click(object sender, EventArgs e)
		{
			if (painelLogin == false)
			{
				
				int Py;
				int Px;
				if (painelConfiguracoes == true)
				{
					// mecher na label
					label3.ForeColor = Color.Black;
					Py = 270;
					Px = 22;
					for (int i = Px; i > 12; i--)
					{
						label3.Location = new Point(i, Py);
						await Task.Delay(2);
					}
					// mecher no painel
					label3click = false;
					Py = panel2.Location.Y;
					Px = panel2.Location.X;
					for (int i = 540; Py <= i; Py += 10)
					{
						panel2.Location = new Point(Px, Py);
						await Task.Delay(1);
					}
					label2.ForeColor = Color.Aqua; //mudar a cor
					painelConfiguracoes = false;
				}
				label2click = true;
				label2.Location = new Point(22, label2.Location.Y); ;
				Py = panel1.Location.Y;
				Px = panel1.Location.X;
				for (int i = 140; i <= Py; Py -= 10)
				{
					panel1.Location = new Point(Px, Py);
					await Task.Delay(1);
				}
				painelLogin = true;
				label2.ForeColor = Color.Aqua; //mudar a cor
			}
			else
			{
				label2click = false;
				int Py = panel1.Location.Y;
				int Px = panel1.Location.X;
				for (int i = 540; Py <= i; Py += 10)
				{
					panel1.Location = new Point(Px, Py);
					await Task.Delay(1);
				}
				painelLogin = false;
			}
		}
		private async void label3_Click(object sender, EventArgs e)
		{
			if (painelConfiguracoes == false)
			{
				int Py;
				int Px;
				if (painelLogin == true) ;
				{
					// mecher na label
					label2.ForeColor = Color.Black;
					Py = 240;
					Px = 22;
					for (int i = Px; i > 12; i--)
					{
						label2.Location = new Point(i, Py);
						await Task.Delay(2);
					}
					// mecher no painel
					label2click = false;
					Py = panel1.Location.Y;
					Px = panel1.Location.X;
					for (int i = 540; Py <= i; Py += 10)
					{
						panel1.Location = new Point(Px, Py);
						await Task.Delay(1);
					}
					painelLogin = false;
					label3.ForeColor = Color.Aqua; //mudar a cor
				}
				label3click = true;
				label3.Location = new Point(22, label3.Location.Y); ;
				Py = panel2.Location.Y;
				Px = panel2.Location.X;
				for (int i = 140; i <= Py; Py -= 10)
				{
					panel2.Location = new Point(Px, Py);
					await Task.Delay(1);
				}
				painelConfiguracoes = true;
				label3.ForeColor = Color.Aqua; //mudar a cor
			}
			else
			{
				label3click = false;
				int Py = panel2.Location.Y;
				int Px = panel2.Location.X;
				for (int i = 540; Py <= i; Py += 10)
				{
					panel2.Location = new Point(Px, Py);
					await Task.Delay(1);
				}
				painelConfiguracoes = false;
			}
		}
		private async void label4_Click(object sender, EventArgs e)
		{
			CriarConta cadastro = new CriarConta();
			this.Hide();
			cadastro.ShowDialog();
			this.Show();
		}
		//
		//
		//
		private async void ImagemFundoMenu()
		{
			/*
			// sobe 3 pastas: Debug -> bin -> TCC_CG_0.0.0.3 (interno)
			// depois cai no TCC_CG_0.0.0.3 principal e entra em imagem_form1
			string pastaImagens = Path.Combine(Application.StartupPath, @"..\..\..\..\imagem_form1");
			string caminhoImagem = Path.Combine(pastaImagens, "IMG-20251005-WA0001.jpg");
			// Aplicar como fundo
			this.BackgroundImage = Image.FromFile(Path.GetFullPath(caminhoImagem));
			this.BackgroundImageLayout = ImageLayout.Stretch;
			*/
		}

	}
}
