﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC_CG_0._0._0._3
{
	internal class FrontEndComand
	{
		private Form form;
		public FrontEndComand(Form form)
		{
			this.form = form;
		}
		// não consegui mecher, area morta

		public void labelMoveAndPainelMove(int Px, int Py, bool[] painel, int numerolabel) // label posição x e y, painel referente a label
		{
			var label = form.Controls.Find("label" + numerolabel, true).FirstOrDefault();
		}
	}
}
