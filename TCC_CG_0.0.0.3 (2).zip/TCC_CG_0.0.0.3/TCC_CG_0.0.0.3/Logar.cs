﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;

namespace TCC_CG_0._0._0._3
{
	public partial class Logar : Form
	{
		public Logar()
		{
			InitializeComponent();
			//AplicarEstiloModerno();
		}
		private void AplicarEstiloModerno()
		{
			// Estilo do formulário
			this.FormBorderStyle = FormBorderStyle.None;
			this.BackColor = Color.FromArgb(34, 34, 34);
			this.ForeColor = Color.White;

			// Fonte moderna
			Font fonteNormal = new Font("Segoe UI", 11, FontStyle.Regular);
			Font fonteTitulo = new Font("Segoe UI Semibold", 18, FontStyle.Bold);

			// Label principal (título)
			label1.Font = fonteTitulo;
			label1.ForeColor = Color.White;

			// Labels dos campos
			label2.Font = fonteNormal;
			label2.ForeColor = Color.White;

			label3.Font = fonteNormal;
			label3.ForeColor = Color.White;

			// TextBoxes
			TextBox[] caixasTexto = { textBox1, textBox2 };
			foreach (TextBox txt in caixasTexto)
			{
				txt.BackColor = Color.FromArgb(45, 45, 48);
				txt.ForeColor = Color.White;
				txt.Font = new Font("Segoe UI", 10, FontStyle.Regular);
				txt.BorderStyle = BorderStyle.FixedSingle;
			}

			// Campo de senha: esconder caracteres
			textBox2.UseSystemPasswordChar = true;

			// Botão
			button4.Text = "Prosseguir";
			button4.FlatStyle = FlatStyle.Flat;
			button4.FlatAppearance.BorderSize = 0;
			button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(80, 80, 80);
			button4.BackColor = Color.FromArgb(64, 64, 64);
			button4.ForeColor = Color.White;
			button4.Font = fonteNormal;

			// Arredondar botão (opcional)
			button4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button4.Width, button4.Height, 10, 10));
		}

		private void button4_Click(object sender, EventArgs e)
		{
			string nome = textBox1.Text;
			string senha = textBox2.Text;
			string senhaHash = Cripto_Hash.GerarHashSha256(senha);
			JogadorRepository repo = new JogadorRepository(CodBD.connection);
			if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(senha))
			{
				label4.Text = "> Erro: Preencha todos os campos";
				return;
			}
			Jogador player = repo.ObterPorNomeESenha(nome, senhaHash);
			if (player != null)
			{
				MenuDoJogador Menu = new MenuDoJogador(player);
				this.Hide();
				Menu.ShowDialog();
				this.Show();
			}

		}

		// não faço ideia [RaulMig]
		[DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
		private static extern IntPtr CreateRoundRectRgn(
			int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
			int nWidthEllipse, int nHeightEllipse);

		private void label1_Click(object sender, EventArgs e)
		{
			this.Hide();
		}

		private void label2_Click(object sender, EventArgs e)
		{

		}
	}
}
