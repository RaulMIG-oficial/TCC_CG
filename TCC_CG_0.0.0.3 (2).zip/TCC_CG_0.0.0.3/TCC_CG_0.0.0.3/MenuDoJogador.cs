﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TCC_CG_0._0._0._3
{
	internal partial class MenuDoJogador : Form
	{
		public Jogador UsuarioAtual = null;
		public MenuDoJogador(Jogador player)
		{
			InitializeComponent();
			//AplicarEstiloModerno();
			this.UsuarioAtual = player;
		}

		private void AplicarEstiloModerno()
		{
			// Formulário
			this.FormBorderStyle = FormBorderStyle.None;
			this.BackColor = Color.FromArgb(34, 34, 34); // fundo escuro
			this.ForeColor = Color.White;

			// Fonte moderna
			Font fonteModerna = new Font("Segoe UI", 11, FontStyle.Regular);

			// Estilo do label
			label1.Font = new Font("Segoe UI Semibold", 16, FontStyle.Bold);
			label1.ForeColor = Color.White;

			// Painel
			//panel1.BackColor = Color.FromArgb(45, 45, 48);

			// Estilizar botões
			System.Windows.Forms.Button[] botoes = { button1, button2, button3, button4, button5, button6 };
			foreach (System.Windows.Forms.Button btn in botoes)
			{
				btn.FlatStyle = FlatStyle.Flat;
				btn.Font = fonteModerna;
				btn.ForeColor = Color.White;
				btn.BackColor = Color.FromArgb(64, 64, 64);
				btn.FlatAppearance.BorderSize = 0;
				btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(80, 80, 80);
			}

			// Opcional: arredondar botões
			foreach (System.Windows.Forms.Button btn in botoes)
			{
				btn.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn.Width, btn.Height, 10, 10));
			}
		}

		// Importação para criar cantos arredondados
		[System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
		private static extern IntPtr CreateRoundRectRgn(
			int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
			int nWidthEllipse, int nHeightEllipse);

		private void button3_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{
			this.Hide();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			JogadorRepository jogadorrepository = new JogadorRepository(CodBD.connection);
			jogadorrepository.SetStatusJogo(UsuarioAtual.IdPlayer, 20, 0);


		}

		private void button6_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{

		}

		private async void button6_Click_1(object sender, EventArgs e)
		{
			Jogador oponente = null;
			JogadorRepository jogadorrepository = new JogadorRepository(CodBD.connection);
			int idUsuarioLogado = UsuarioAtual.Id;

			OpenServe openServe = new OpenServe(CodBD.connection);
			List<int> idsServe = openServe.LerIdsServe();

			int idServeUsado = -1;
			bool souJogador1 = false;

			// Método local para animar a label
			async Task AnimarLabelBusca(string textoBase, CancellationToken token)
			{
				int ponto = 0;
				while (!token.IsCancellationRequested)
				{
					label2.Text = textoBase + new string('.', ponto);
					ponto = (ponto + 1) % 4; // 0,1,2,3 pontos
					await Task.Delay(500); // 0.5s entre cada ponto
				}
			}

			// Token para controlar a animação
			CancellationTokenSource cts = new CancellationTokenSource();
			var animacaoTask = AnimarLabelBusca("Procurando partida", cts.Token);

			// Primeiro tenta se conectar a um serve já em andamento
			var resultado1 = openServe.ProcurarServeComJogador1(idsServe);

			if (resultado1 != null)
			{
				resultado1.Jogador = jogadorrepository.PegarIdPlayerAtravezIdJogador(resultado1.Jogador);
				oponente = resultado1.Jogador;
				idServeUsado = resultado1.IdServe;
				int idPlayer = openServe.GarantirPlayer(UsuarioAtual);
				openServe.AtualizarServeParaIniciarPartida(idServeUsado, idPlayer, conectarComoJogador2: true);
			}
			else
			{
				var resultado2 = openServe.ProcurarServeComJogador2(idsServe);
				if (resultado2 != null)
				{
					resultado2.Jogador = jogadorrepository.PegarIdPlayerAtravezIdJogador(resultado2.Jogador);
					oponente = resultado2.Jogador;
					idServeUsado = resultado2.IdServe;
					int idPlayer = openServe.GarantirPlayer(UsuarioAtual);
					openServe.AtualizarServeParaIniciarPartida(idServeUsado, idPlayer, conectarComoJogador2: false);
				}
			}

			// Se não achou ninguém, cria um novo servidor
			if (oponente == null)
			{
				// Primeiro garante que existe um player vinculado ao jogador
				int idPlayer = openServe.GarantirPlayer(UsuarioAtual);
				label2.Text = "Nenhum jogador disponível, aguardando oponente...";
				// Agora reserva o serve usando o id do Player (para não quebrar FK)
				idServeUsado = openServe.ReservarServeParaJogador(idPlayer, comoJogador1: true);
				souJogador1 = true;

				while (oponente == null)
				{
					await Task.Delay(1000); // espera 1s
					oponente = openServe.VerificarSeOponenteEntrou(idServeUsado, souJogador1);
				}

				//MessageBox.Show($"Oponente encontrado: {oponente.Nome}");
			}

			// Para a animação
			cts.Cancel();
			label2.Text = "Oponente encontrado!";

			// Quando achou oponente, abre partida
			if (oponente != null)
			{
				Partida partida = new Partida(UsuarioAtual, oponente);
				this.Hide();
				partida.ShowDialog();
				this.Show();
			}

		}

		private void button5_Click(object sender, EventArgs e)
		{
			OpenServe openServe = new OpenServe(CodBD.connection);
			openServe.Limparserve();
		}

		private void MenuDoJogador_Load(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{

		}
	}
}
