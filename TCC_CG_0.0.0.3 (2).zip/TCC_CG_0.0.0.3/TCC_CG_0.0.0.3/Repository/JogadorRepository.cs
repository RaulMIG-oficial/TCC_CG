﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;

namespace TCC_CG_0._0._0._3.Repository
{
    internal class JogadorRepository
    {
		private readonly string _connectionString;

		public JogadorRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		public Jogador ObterPorNomeESenha(string nome, string senha)
		{
			Jogador usuario = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT id_usuario, nome_usuario, senha, lvl, id_baralho_base, id_baralho_global, win, lose FROM jogador WHERE nome_usuario = @Nome AND senha = @Senha";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Nome", nome);
					command.Parameters.AddWithValue("@Senha", senha);

					using (var reader = command.ExecuteReader())
					{
						BaralhoRepository baralhorepo = new BaralhoRepository(_connectionString);

						if (reader.Read())
						{
							Baralho baralhoB = baralhorepo.ObterBaralhoBasePorId(reader.GetInt32("id_baralho_base"));
							Baralho baralhoG = baralhorepo.ObterBaralhoGlobalPorId(reader.GetInt32("id_baralho_global"));
							usuario = new Jogador
							{
								Id = reader.GetInt32("id_usuario"),
								Nome = reader.GetString("nome_usuario"),
								Senha = reader.GetString("senha"),
								lvl = reader.GetInt32("lvl"),
								BaralhoBase = baralhoB.Cartas,
								BaralhoGlobal = baralhoG.Cartas,
								Win = reader.GetInt32("win"),
								Lose = reader.GetInt32("lose"),
								BaralhoJogo =new Baralho 
								{ 
									CartasList = baralhorepo.ObterListCartas(baralhoG) 
								}
							};
							usuario = PegarIdPlayerAtravezIdJogador(usuario);
						}
					}
				}
			}
			return usuario;
		}
		public Jogador ObterPorNome(string nome)
		{
			Jogador usuario = new Jogador { Nome = "Fall" };
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT nome_usuario FROM jogador WHERE nome_usuario = @Nome ";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Nome", nome);
					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							usuario = new Jogador
							{
								Nome = reader.GetString("nome_usuario"),
							};
						}
					}
				}
			}
			return usuario;
		}
		public int InserirJogador(Jogador usuario, int IdBB, int IdBG)
		{
			int linhasAfetadas = -1;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "INSERT INTO Jogador (nome_usuario, lvl, senha,id_baralho_base,id_baralho_global,Win,Lose) VALUES (@Nome, @Lvl, @Senha, @IdBB, @IdBG, @Win, @Lose)";
				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@Nome", usuario.Nome);
					command.Parameters.AddWithValue("@Lvl", usuario.lvl);
					command.Parameters.AddWithValue("@Senha", usuario.Senha);
					command.Parameters.AddWithValue("@IdBB", IdBB);
					command.Parameters.AddWithValue("@IdBG", IdBG);
					command.Parameters.AddWithValue("@Win", usuario.Win);
					command.Parameters.AddWithValue("@Lose", usuario.Lose);

					linhasAfetadas = command.ExecuteNonQuery();
				}
			}
			return linhasAfetadas;
		}
		public Jogador PegarIdPlayerAtravezIdJogador(Jogador jogador)
		{
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT p.id_jogador FROM player p, jogador j WHERE j.id_usuario = @idUsuario AND j.nome_usuario = p.nome";
				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@idUsuario", jogador.Id);
					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							jogador.IdPlayer = reader.GetInt32("id_jogador");
						}
					}
				}
			}
			return jogador;
		}
		public Jogador GetStatusJogo(int id_jogador)
		{
			Jogador jogador = new Jogador();
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT vida, escudo FROM player WHERE id_jogador = @Id";
				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@Id", id_jogador);
					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							jogador = new Jogador
							{
								HP = reader.GetInt32("vida"),
								Def = reader.GetInt32("escudo")
							};
						}
					}
				}
			}
			return jogador;
		}
		public void SetStatusJogo(int id_jogador, int HP_jogador, int Def_jogador)
		{
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();

				string query = @"UPDATE player SET vida = @vida, escudo = @escudo WHERE id_jogador = @Id_jogador;";

				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@Id_jogador", id_jogador);
					command.Parameters.AddWithValue("@vida", HP_jogador);
					command.Parameters.AddWithValue("@escudo", Def_jogador);

					command.ExecuteNonQuery();
				}
			}
		}
	}
}
