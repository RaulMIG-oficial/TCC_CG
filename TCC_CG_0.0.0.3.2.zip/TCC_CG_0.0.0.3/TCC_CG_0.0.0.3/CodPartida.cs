﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;

namespace TCC_CG_0._0._0._3
{
	internal class CodPartida
	{
		private readonly string _connectionString;
		public Jogador jogadorhost;
		public JogadorRepository jogadorrepository = new JogadorRepository(CodBD.connection);
		public BaralhoRepository baralhorepository = new BaralhoRepository(CodBD.connection);
		 public CodPartida (string connectionString,Jogador jogadorhost)
		{
			_connectionString = connectionString;
			this.jogadorhost = jogadorhost;
		}
		public int VerificarJogador()
		{
			int result = 0;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT vez, id_player1, id_player2 FROM serve WHERE id_player1 = @Id OR id_player2 = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", jogadorhost.IdPlayer);

					using (var reader = command.ExecuteReader())
					{

						if (reader.Read())
						{
							int play1 = reader.GetInt32("id_player1");
							int play2 = reader.GetInt32("id_player2");
							if (play1 == jogadorhost.IdPlayer)
							{
								// ele é o jogador 1
								return result = 1;
							}
							else if (play2 == jogadorhost.IdPlayer)
							{
								// ele é o jogador 2
								return result = 2;
							}
							
						}
					}
				}
			}
			return result;
		}
		public int VerificarVez(Jogador jogador)
		{
			int vez = 0;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT vez FROM serve WHERE id_player1 = @Id OR id_player2 = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", jogador.IdPlayer);

					using (var reader = command.ExecuteReader())
					{

						if (reader.Read())
						{
							vez = reader.GetInt32("vez");
						}
					}
				}
			}
			return vez;
		}
		public int[] LerCartasEscolhidas(bool[] labelcartas,List<Carta> cartas)
		{
			int Dano = 0;
			int Cura = 0;
			int Defende = 0;
			for (int i = 0; i < labelcartas.Length; i++)
			{
				if (labelcartas[i] == true)
				{
					Dano = cartas[i].Dano + Dano;
					Cura = cartas[i].Cura + Cura;
					Defende = cartas[i].Defesa + Defende;
				}
			}
			int[] dados = {Dano,Cura, Defende};

			return dados;
		}
		public void MudarVez(int id_player1, int id_player2)
		{
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();

				string query = @"
            UPDATE serve
            SET vez = CASE 
                        WHEN vez = 1 THEN 2
                        WHEN vez = 2 THEN 1
                        ELSE vez
                      END
            WHERE id_player1 = @id_player1 AND id_player2 = @id_player2;";

				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@id_player1", id_player1);
					command.Parameters.AddWithValue("@id_player2", id_player2);

					command.ExecuteNonQuery();
				}
			}
		}
		public Jogador OrganizarCarta(Jogador jogador)
		{
			// Garante que as listas não são nulas
			if (jogador.BaralhoJogo == null)
				jogador.BaralhoJogo = new Baralho { CartasList = new List<Carta>() };
			if (jogador.BaralhoJogo.CartasList == null)
				jogador.BaralhoJogo.CartasList = new List<Carta>();
			if (jogador.Cemiterio == null)
				jogador.Cemiterio = new List<Carta>();

			List<Carta> cartaslistaTotal = jogador.BaralhoJogo.CartasList;
			List<Carta> cartaslistaCemiterio = jogador.Cemiterio;

			// Se o baralho tiver menos que 5 cartas, recicla do cemitério
			if (cartaslistaTotal.Count < 5 && cartaslistaCemiterio.Count > 0)
			{
				baralhorepository.Embaralhar(cartaslistaCemiterio, 50);

				while (cartaslistaTotal.Count < 5 && cartaslistaCemiterio.Count > 0)
				{
					cartaslistaTotal.Add(cartaslistaCemiterio[0]);
					cartaslistaCemiterio.RemoveAt(0);
				}
			}
			else
			{
				// Move até 5 cartas do baralho para o cemitério
				int qtdParaMover = Math.Min(5, cartaslistaTotal.Count);
				for (int i = 0; i < qtdParaMover; i++)
				{
					cartaslistaCemiterio.Add(cartaslistaTotal[0]);
					cartaslistaTotal.RemoveAt(0);
				}
				if (cartaslistaTotal.Count < 5 && cartaslistaCemiterio.Count > 0)
				{
					baralhorepository.Embaralhar(cartaslistaCemiterio, 50);

					while (cartaslistaTotal.Count < 5 && cartaslistaCemiterio.Count > 0)
					{
						cartaslistaTotal.Add(cartaslistaCemiterio[0]);
						cartaslistaCemiterio.RemoveAt(0);
					}
				}
			}
			

			jogador.BaralhoJogo.CartasList = cartaslistaTotal;
			jogador.Cemiterio = cartaslistaCemiterio;

			return jogador;
		}
	}
}
