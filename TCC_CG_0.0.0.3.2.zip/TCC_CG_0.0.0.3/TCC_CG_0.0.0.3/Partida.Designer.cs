﻿namespace TCC_CG_0._0._0._3
{
    partial class Partida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			panel1 = new Panel();
			panel2 = new Panel();
			panel3 = new Panel();
			panel4 = new Panel();
			panel5 = new Panel();
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			button1 = new Button();
			label5 = new Label();
			label6 = new Label();
			label7 = new Label();
			label8 = new Label();
			label9 = new Label();
			SuspendLayout();
			// 
			// panel1
			// 
			panel1.BackColor = SystemColors.ButtonShadow;
			panel1.Location = new Point(73, 255);
			panel1.Name = "panel1";
			panel1.Size = new Size(112, 174);
			panel1.TabIndex = 0;
			panel1.Click += panel1_Click;
			// 
			// panel2
			// 
			panel2.BackColor = SystemColors.ButtonShadow;
			panel2.Location = new Point(191, 255);
			panel2.Name = "panel2";
			panel2.Size = new Size(112, 174);
			panel2.TabIndex = 1;
			panel2.Click += panel2_Click;
			// 
			// panel3
			// 
			panel3.BackColor = SystemColors.ButtonShadow;
			panel3.Location = new Point(309, 255);
			panel3.Name = "panel3";
			panel3.Size = new Size(112, 174);
			panel3.TabIndex = 1;
			panel3.Click += panel3_Click;
			// 
			// panel4
			// 
			panel4.BackColor = SystemColors.ButtonShadow;
			panel4.Location = new Point(427, 255);
			panel4.Name = "panel4";
			panel4.Size = new Size(112, 174);
			panel4.TabIndex = 2;
			panel4.Click += panel4_Click;
			// 
			// panel5
			// 
			panel5.BackColor = SystemColors.ButtonShadow;
			panel5.Location = new Point(545, 255);
			panel5.Name = "panel5";
			panel5.Size = new Size(112, 174);
			panel5.TabIndex = 2;
			panel5.Click += panel5_Click;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(25, 75);
			label1.Name = "label1";
			label1.Size = new Size(37, 15);
			label1.TabIndex = 3;
			label1.Text = "Mana";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(309, 30);
			label2.Name = "label2";
			label2.Size = new Size(95, 15);
			label2.TabIndex = 4;
			label2.Text = "vez do oponente";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(25, 30);
			label3.Name = "label3";
			label3.Size = new Size(49, 15);
			label3.TabIndex = 5;
			label3.Text = "Jogador";
			label3.Click += label3_Click;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(25, 45);
			label4.Name = "label4";
			label4.Size = new Size(68, 15);
			label4.TabIndex = 6;
			label4.Text = "HP Jogador";
			// 
			// button1
			// 
			button1.Location = new Point(687, 355);
			button1.Name = "button1";
			button1.Size = new Size(75, 23);
			button1.TabIndex = 7;
			button1.Text = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(624, 45);
			label5.Name = "label5";
			label5.Size = new Size(79, 15);
			label5.TabIndex = 9;
			label5.Text = "HP Oponente";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(624, 30);
			label6.Name = "label6";
			label6.Size = new Size(60, 15);
			label6.TabIndex = 8;
			label6.Text = "Oponente";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(25, 60);
			label7.Name = "label7";
			label7.Size = new Size(90, 15);
			label7.TabIndex = 10;
			label7.Text = "Escudo Jogador";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(624, 60);
			label8.Name = "label8";
			label8.Size = new Size(101, 15);
			label8.TabIndex = 11;
			label8.Text = "Escudo Oponente";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(73, 136);
			label9.Name = "label9";
			label9.Size = new Size(73, 15);
			label9.TabIndex = 12;
			label9.Text = "Informações";
			// 
			// Partida
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(label9);
			Controls.Add(label8);
			Controls.Add(label7);
			Controls.Add(label5);
			Controls.Add(label6);
			Controls.Add(button1);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Controls.Add(panel4);
			Controls.Add(panel5);
			Controls.Add(panel2);
			Controls.Add(panel3);
			Controls.Add(panel1);
			Name = "Partida";
			Text = "Partida";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Panel panel1;
		private Panel panel2;
		private Panel panel3;
		private Panel panel4;
		private Panel panel5;
		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private Button button1;
		private Label label5;
		private Label label6;
		private Label label7;
		private Label label8;
		private Label label9;
	}
}