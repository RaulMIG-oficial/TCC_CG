﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;

namespace TCC_CG_0._0._0._3.Repository
{
	internal class CartaRepository
	{
		public List<int> CriarListCartas(Baralho baralho)
		{
			string[] numcartas = baralho.Cartas.ToString().Split(',');
			List<int> idcarta = new List<int>();

			foreach (var item in numcartas)
			{
				if (int.TryParse(item.Trim(), out int id))
					idcarta.Add(id);
			}

			return idcarta;
		}
	}
	// n sei explicar-----------------
	public static class ConversorImagem 
	{
		public static byte[] ParaBytes(Image img)
		{
			using (MemoryStream ms = new MemoryStream())
			{
				img.Save(ms, img.RawFormat);
				return ms.ToArray();
			}
		}

		public static Image ParaImagem(byte[] bytes)
		{
			if (bytes == null || bytes.Length == 0)
				return null;

			using (var ms = new MemoryStream(bytes))
			{
				// Cria um Bitmap independente do MemoryStream
				return new Bitmap(ms);
			}
		}
	}
	// ---------------------------------
}
