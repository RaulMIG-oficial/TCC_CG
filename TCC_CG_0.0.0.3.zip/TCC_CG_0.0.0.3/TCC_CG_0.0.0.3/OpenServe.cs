﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Crypto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;

namespace TCC_CG_0._0._0._3
{
	internal class OpenServe
	{
		public class ResultadoBusca
		{
			public Jogador Jogador { get; set; }
			public int IdServe { get; set; }
		}
		JogadorRepository jogadorrepository = new JogadorRepository(CodBD.connection);
		private readonly string _connectionString;

		public OpenServe(string connectionString)
		{
			_connectionString = connectionString;
		}
		public List<int> LerIdsServe()
		{
			List<int> ids = new List<int>();

			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					string sql = "SELECT id_serve FROM serve";
					using (MySqlCommand cmd = new MySqlCommand(sql, conn))
					using (MySqlDataReader reader = cmd.ExecuteReader())
					{
						while (reader.Read())
						{
							if (!reader.IsDBNull(0))
							{
								ids.Add(reader.GetInt32(0));
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao ler IDs: " + ex.Message);
			}

			return ids;
		}
		public ResultadoBusca ProcurarServeComJogador1(List<int> serves)
		{
			ResultadoBusca resultado = null;

			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					string idsServe = string.Join(",", serves);

					string sql = $@"
                SELECT s.id_serve, j.id_usuario, j.nome_usuario, j.lvl, j.Win, j.Lose, j.id_baralho_global
                FROM serve s
                INNER JOIN player p ON s.id_player1 = p.id_jogador
                INNER JOIN jogador j ON j.nome_usuario = p.nome
                WHERE s.jogador1 = 1 AND s.id_serve IN ({idsServe})
                LIMIT 1;
            ";
					using (MySqlCommand cmd = new MySqlCommand(sql, conn))
					using (MySqlDataReader reader = cmd.ExecuteReader())
					{
						if (reader.Read())
						{
							var baralhoRepo = new BaralhoRepository(_connectionString);

							resultado = new ResultadoBusca
							{
								IdServe = reader.GetInt32("id_serve"),
								Jogador = new Jogador
								{
									Id = reader.GetInt32("id_usuario"),
									Nome = reader.GetString("nome_usuario"),
									Win = reader.GetInt32("Win"),
									Lose = reader.GetInt32("Lose"),
									BaralhoGlobal = baralhoRepo.ObterBaralhoGlobalPorId(reader.GetInt32("id_baralho_global")).Cartas
								}
							};
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao procurar serve com jogador1: " + ex.Message);
			}

			return resultado;
		}
		public ResultadoBusca ProcurarServeComJogador2(List<int> serves)
		{
			ResultadoBusca resultado = null;

			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					string idsServe = string.Join(",", serves);

					string sql = $@"
                SELECT s.id_serve, j.id_usuario, j.nome_usuario, j.lvl, j.Win, j.Lose, j.id_baralho_global
                FROM serve s
                INNER JOIN player p ON s.id_player2 = p.id_jogador
                INNER JOIN jogador j ON j.nome_usuario = p.nome
                WHERE s.jogador2 = 1 AND s.id_serve IN ({idsServe})
                LIMIT 1;
            ";

					using (MySqlCommand cmd = new MySqlCommand(sql, conn))
					using (MySqlDataReader reader = cmd.ExecuteReader())
					{
						if (reader.Read())
						{
							var baralhoRepo = new BaralhoRepository(_connectionString);

							resultado = new ResultadoBusca
							{
								IdServe = reader.GetInt32("id_serve"),
								Jogador = new Jogador
								{
									Id = reader.GetInt32("id_usuario"),
									Nome = reader.GetString("nome_usuario"),
									Win = reader.GetInt32("Win"),
									Lose = reader.GetInt32("Lose"),
									BaralhoGlobal = baralhoRepo.ObterBaralhoGlobalPorId(reader.GetInt32("id_baralho_global")).Cartas
								}
							};
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao procurar serve com jogador2: " + ex.Message);
			}

			return resultado;
		}
		public int ReservarServeParaJogador(int idUsuario, bool comoJogador1)
		{
			int idServe = -1;

			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					// Pega um servidor livre
					string sqlBusca = "SELECT id_serve FROM serve WHERE jogador1 = 0 AND jogador2 = 0 LIMIT 1";
					using (MySqlCommand cmdBusca = new MySqlCommand(sqlBusca, conn))
					using (var reader = cmdBusca.ExecuteReader())
					{
						if (reader.Read())
							idServe = reader.GetInt32("id_serve");
					}
					conn.Close();

					if (idServe == -1) return -1; // nenhum serve livre

					conn.Open();
					string sqlUpdate = comoJogador1
						? @"UPDATE serve SET jogador1 = 1, id_player1 = @idUsuario WHERE id_serve = @idServe"
						: @"UPDATE serve SET jogador2 = 1, id_player2 = @idUsuario WHERE id_serve = @idServe";

					using (MySqlCommand cmd = new MySqlCommand(sqlUpdate, conn))
					{
						cmd.Parameters.AddWithValue("@idUsuario", idUsuario);
						cmd.Parameters.AddWithValue("@idServe", idServe);
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao reservar serve: " + ex.Message);
			}

			return idServe;
		}
		public Jogador VerificarSeOponenteEntrou(int idServe, bool souJogador1)
		{
			Jogador oponente = null;

			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					string sql = souJogador1
						? @"SELECT j.id_usuario, j.nome_usuario, j.lvl, j.Win, j.Lose, j.id_baralho_global
                    FROM serve s
                    INNER JOIN player p ON s.id_player2 = p.id_jogador
                    INNER JOIN jogador j ON j.nome_usuario = p.nome
                    WHERE s.id_serve = @idServe AND s.jogador2 = 1"
						: @"SELECT j.id_usuario, j.nome_usuario, j.lvl, j.Win, j.Lose, j.id_baralho_global
                    FROM serve s
                    INNER JOIN player p ON s.id_player1 = p.id_jogador
                    INNER JOIN jogador j ON j.nome_usuario = p.nome
                    WHERE s.id_serve = @idServe AND s.jogador1 = 1";

					using (MySqlCommand cmd = new MySqlCommand(sql, conn))
					{
						cmd.Parameters.AddWithValue("@idServe", idServe);
						using (var reader = cmd.ExecuteReader())
						{
							if (reader.Read())
							{
								var baralhoRepo = new BaralhoRepository(_connectionString);

								oponente = new Jogador
								{
									Id = reader.GetInt32("id_usuario"),
									Nome = reader.GetString("nome_usuario"),
									Win = reader.GetInt32("Win"),
									Lose = reader.GetInt32("Lose"),
									BaralhoGlobal = baralhoRepo.ObterBaralhoGlobalPorId(reader.GetInt32("id_baralho_global")).Cartas
								};
								oponente = jogadorrepository.PegarIdPlayerAtravezIdJogador(oponente);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao verificar oponente: " + ex.Message);
			}

			return oponente;
		}
		public void AtualizarServeParaIniciarPartida(int idServe, int idUsuario, bool conectarComoJogador2)
		{
			try
			{
				using (MySqlConnection conn = new MySqlConnection(_connectionString))
				{
					conn.Open();

					string sql;
					if (conectarComoJogador2)
					{
						sql = @"UPDATE serve 
                        SET id_player2 = @idUsuario, jogador2 = 1 
                        WHERE id_serve = @idServe";
					}
					else
					{
						sql = @"UPDATE serve 
                        SET id_player1 = @idUsuario, jogador1 = 1 
                        WHERE id_serve = @idServe";
					}

					using (MySqlCommand cmd = new MySqlCommand(sql, conn))
					{
						cmd.Parameters.AddWithValue("@idUsuario", idUsuario);
						cmd.Parameters.AddWithValue("@idServe", idServe);
						cmd.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Erro ao atualizar serve: " + ex.Message);
			}
		}
		public int GarantirPlayer(Jogador usuario)
		{
			int idPlayer = -1;
			using (var conn = new MySqlConnection(_connectionString))
			{
				conn.Open();

				// Verifica se já existe um player com o mesmo nome do Jogador
				string sqlCheck = "SELECT id_jogador FROM player WHERE nome = @Nome";
				using (var cmdCheck = new MySqlCommand(sqlCheck, conn))
				{
					cmdCheck.Parameters.AddWithValue("@Nome", usuario.Nome);
					var result = cmdCheck.ExecuteScalar();
					if (result != null)
					{
						idPlayer = Convert.ToInt32(result);
					}
					else
					{
						// Se não existir, cria um novo player
						string sqlInsert = "INSERT INTO player (nome) VALUES (@Nome); SELECT LAST_INSERT_ID();";
						using (var cmdInsert = new MySqlCommand(sqlInsert, conn))
						{
							cmdInsert.Parameters.AddWithValue("@Nome", usuario.Nome);
							idPlayer = Convert.ToInt32(cmdInsert.ExecuteScalar());
						}
					}
				}
			}
			return idPlayer;
		}
		public void Limparserve()
		{

			using (MySqlConnection conn = new MySqlConnection(_connectionString))
			{
				conn.Open();

				string query = @"
            UPDATE serve 
            SET jogador1 = 0, 
                jogador2 = 0, 
                vez = 1, 
                id_player1 = NULL, 
                id_player2 = NULL;";
				using (MySqlCommand cmd = new MySqlCommand(query, conn))
				{
					int linhasAfetadas = cmd.ExecuteNonQuery();
					Console.WriteLine($"{linhasAfetadas} linhas atualizadas na tabela serve.");
				}
			}
		}
		public void SetPlayerStatus(int id_player)
		{
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();

				string query = @"
            UPDATE player
            SET vida = 20, escudo = 0
            WHERE id_jogador = @id_player;";

				using (var command = new MySqlCommand(query, connection))
				{
					command.Parameters.AddWithValue("@id_player", id_player);
					command.ExecuteNonQuery();
				}
			}
		}
	}
	
}
