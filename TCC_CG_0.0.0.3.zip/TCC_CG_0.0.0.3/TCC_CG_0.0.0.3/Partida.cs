﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TCC_CG_0._0._0._3.Objetos;
using TCC_CG_0._0._0._3.Repository;

namespace TCC_CG_0._0._0._3
{
	internal partial class Partida : Form
	{

		public Jogador jogador = new Jogador();
		public Jogador oponente = new Jogador();
		public JogadorRepository jogadorrepository = new JogadorRepository(CodBD.connection);
		public BaralhoRepository baralhorepository = new BaralhoRepository(CodBD.connection);
		CodPartida Codpartida;
		int vez = 0;
		int play = 0;
		bool[] cartaescolhida = { false, false, false, false, false };
		int contclick = 0;
		public Partida(Jogador player, Jogador oponente)
		{
			//======= algo ====================
			InitializeComponent();
			this.jogador = player;
			this.oponente = oponente;
			Codpartida = new CodPartida(CodBD.connection, jogador);
			//======= Caregar tela ============
			CaregarINF(true);
			//======= ver vez =================
			vez = Codpartida.VerificarJogador();
			if (vez == 1)
			{
				label2.Text = "Sua vez de jogar";
				play = 1;
			}
			else if (vez == 2)
			{
				label2.Text = "vez do oponente";
				play = 2;
				Espera();
				label2.Text = "Sua vez de jogar";
			}
			else
			{
				label2.Text = "ERRO";
			}
		}
		private void panel1_Click(object sender, EventArgs e)
		{
			if ((jogador.Mana > 0) && (cartaescolhida[0] == false))
			{
				panel1.Location = new Point(73, 240);
				cartaescolhida[0] = true;
				jogador.Mana--;
			}
			else if (cartaescolhida[0] == true)
			{
				panel1.Location = new Point(73, 255);
				cartaescolhida[0] = false;
				jogador.Mana++;
			}
			label1.Text = "Mana: 3/" + jogador.Mana;
		}
		private void panel2_Click(object sender, EventArgs e)
		{
			if ((jogador.Mana > 0) && (cartaescolhida[1] == false))
			{
				panel2.Location = new Point(191, 240);
				cartaescolhida[1] = true;
				jogador.Mana--;
			}
			else if (cartaescolhida[1] == true)
			{
				panel2.Location = new Point(191, 255);
				cartaescolhida[1] = false;
				jogador.Mana++;
			}
			label1.Text = "Mana: 3/" + jogador.Mana;
		}

		private void panel3_Click(object sender, EventArgs e)
		{
			if ((jogador.Mana > 0) && (cartaescolhida[2] == false))
			{
				panel3.Location = new Point(309, 240);
				cartaescolhida[2] = true;
				jogador.Mana--;
			}
			else if (cartaescolhida[2] == true)
			{
				panel3.Location = new Point(309, 255);
				cartaescolhida[2] = false;
				jogador.Mana++;
			}
			label1.Text = "Mana: 3/" + jogador.Mana;
		}

		private void panel4_Click(object sender, EventArgs e)
		{
			if ((jogador.Mana > 0) && (cartaescolhida[3] == false))
			{
				panel4.Location = new Point(427, 240);
				cartaescolhida[3] = true;
				jogador.Mana--;
			}
			else if (cartaescolhida[3] == true)
			{
				panel4.Location = new Point(427, 255);
				cartaescolhida[3] = false;
				jogador.Mana++;
			}
			label1.Text = "Mana: 3/" + jogador.Mana;
		}

		private void panel5_Click(object sender, EventArgs e)
		{
			if ((jogador.Mana > 0) && (cartaescolhida[4] == false))
			{
				panel5.Location = new Point(545, 240);
				cartaescolhida[4] = true;
				jogador.Mana--;
			}
			else if (cartaescolhida[4] == true)
			{
				panel5.Location = new Point(545, 255);
				cartaescolhida[4] = false;
				jogador.Mana++;
			}
			label1.Text = "Mana: 3/" + jogador.Mana;
		}
		public void CaregarINF(bool embaralhar)
		{
			jogador.HP = jogadorrepository.GetStatusJogo(jogador.IdPlayer).HP;
			jogador.Def = jogadorrepository.GetStatusJogo(jogador.IdPlayer).Def;
			oponente.HP = jogadorrepository.GetStatusJogo(oponente.IdPlayer).HP;
			oponente.Def = jogadorrepository.GetStatusJogo(oponente.IdPlayer).Def;
			label3.Text = "Jogador: " + jogador.Nome;
			label4.Text = "HP: " + jogador.HP_Base + "/" + jogador.HP;
			label1.Text = "Mana: 3/" + jogador.Mana;
			label6.Text = "Oponente: " + oponente.Nome;
			label5.Text = "HP: " + oponente.HP_Base + "/" + oponente.HP;
			label7.Text = "Def: " + jogador.Def;
			label8.Text = "Def: " + oponente.Def;
			if (embaralhar == true)
			{
				baralhorepository.Embaralhar(jogador.BaralhoJogo.CartasList, 50);
			}
			{
				//===========================imagem carta 1=======================

				var img = jogador.BaralhoJogo.CartasList[0].Imagem;
				if (img != null)
				{
					panel1.BackgroundImage = img;
					panel1.BackgroundImageLayout = ImageLayout.Stretch; // ajusta a imagem ao tamanho do panel
				}
				else
				{
					MessageBox.Show("A carta não tem imagem salva no banco.");
				}

				//===========================imagem carta 2=======================
					img = jogador.BaralhoJogo.CartasList[1].Imagem;
				if (img != null)
				{
					panel2.BackgroundImage = img;
					panel2.BackgroundImageLayout = ImageLayout.Stretch; // ajusta a imagem ao tamanho do panel
				}
				else
				{
					MessageBox.Show("A carta não tem imagem salva no banco.");
				}

				//===========================imagem carta 3=======================

				img = jogador.BaralhoJogo.CartasList[2].Imagem;
				if (img != null)
				{
					panel3.BackgroundImage = img;
					panel3.BackgroundImageLayout = ImageLayout.Stretch; // ajusta a imagem ao tamanho do panel
				}
				else
				{
					MessageBox.Show("A carta não tem imagem salva no banco.");
				}

				//===========================imagem carta 4=======================

				img = jogador.BaralhoJogo.CartasList[3].Imagem;
				if (img != null)
				{
					panel4.BackgroundImage = img;
					panel4.BackgroundImageLayout = ImageLayout.Stretch; // ajusta a imagem ao tamanho do panel
				}
				else
				{
					MessageBox.Show("A carta não tem imagem salva no banco.");
				}

				//===========================imagem carta 5=======================

				img = jogador.BaralhoJogo.CartasList[4].Imagem;
				if (img != null)
				{
					panel5.BackgroundImage = img;
					panel5.BackgroundImageLayout = ImageLayout.Stretch; // ajusta a imagem ao tamanho do panel
				}
				else
				{
					MessageBox.Show("A carta não tem imagem salva no banco.");
				}
				//============================ Fim ===============================
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			CaregarINF(false);
			if ((vez == 1) && (play == 1) || (vez == 2) && (play == 2))
			{
				if (jogador.Mana > 0)
				{
					contclick++;
					label9.Text = "Vc ainda tem Mana para gastar, se deseja jogar mesmo assim click novamente";
				}
				else if (jogador.Mana == 0)
				{
					contclick++;
					label9.Text = "Click novamente";
				}
				if (contclick == 2)
				{
					label9.Text = "Jogo";
					int[] dados = Codpartida.LerCartasEscolhidas(cartaescolhida, jogador.BaralhoJogo.CartasList); // Dano,Cura,Defende
					jogador.Def = jogador.Def + dados[2];
					jogador.HP = jogador.HP + dados[1];
					if (jogador.HP > jogador.HP_Base)
					{
						jogador.HP = jogador.HP_Base;
					}
					oponente.Def = oponente.Def - dados[0];
					if (oponente.Def < 0)
					{
						oponente.HP = oponente.HP + oponente.Def; // Def é negativo 
						oponente.Def = 0;
					}
					jogadorrepository.SetStatusJogo(jogador.IdPlayer, jogador.HP, jogador.Def);
					jogadorrepository.SetStatusJogo(oponente.IdPlayer, oponente.HP, oponente.Def);
					jogador.HP = jogadorrepository.GetStatusJogo(jogador.IdPlayer).HP;
					oponente.HP = jogadorrepository.GetStatusJogo(oponente.IdPlayer).HP;
					if (oponente.HP <= 0)
					{
						Console.WriteLine("Você ganhou");
					}
					Codpartida.MudarVez(jogador.IdPlayer, oponente.IdPlayer);
					contclick = 0;
					jogador = Codpartida.OrganizarCarta(jogador);
					Espera();
					label2.Text = "Sua vez de jogar";
					CaregarINF(true);
				}
			}
			else if ((vez == 2) && (play == 1) || (vez == 1) && (play == 2))
			{
				label9.Text = "oponente está jogando";

			}
		}
		public async void Espera()
		{
			async Task AnimarLabelBusca(string textoBase, CancellationToken token)
			{
				int ponto = 0;
				while (!token.IsCancellationRequested)
				{
					label2.Text = textoBase + new string('.', ponto);
					ponto = (ponto + 1) % 4; // 0,1,2,3 pontos
					await Task.Delay(500); // 0.5s entre cada ponto
				}
			}

			// Token para controlar a animação
			CancellationTokenSource cts = new CancellationTokenSource();
			var animacaoTask = AnimarLabelBusca("vez do oponente", cts.Token);

			if (play == 1)
			{
				while (vez != 1)
				{
					await Task.Delay(1000); // espera 1s
					vez = Codpartida.VerificarVez(jogador);
				}
			}
			else if (play == 2)
			{
				while (vez != 2)
				{
					await Task.Delay(1000); // espera 1s
					vez = Codpartida.VerificarVez(jogador);
				}
			}
			CaregarINF(false);
		}

		private void label3_Click(object sender, EventArgs e)
		{
			CaregarINF(false);

			if (oponente.HP <= 0)
			{
				jogador.HP = jogadorrepository.GetStatusJogo(jogador.IdPlayer).HP;
				oponente.HP = jogadorrepository.GetStatusJogo(oponente.IdPlayer).HP;
				if (jogador.HP <= 0)
				{
					Console.WriteLine("Você Perdeu");
				}
			}
		}
	}
}
