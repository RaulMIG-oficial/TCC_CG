﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC_CG_0._0._0._3.Objetos;

namespace TCC_CG_0._0._0._3.Repository
{
    internal class BaralhoRepository
    {
		private readonly string _connectionString;
		private static Random rng = new Random();
		public BaralhoRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		public Baralho ObterBaralhoBasePorId(int IdBaralho)
		{
			Baralho baralho = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT id_baralho, id_cartas_string FROM baralho_base WHERE id_baralho = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", IdBaralho);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							baralho = new Baralho
							{
								Id = IdBaralho,
								Cartas = reader.GetString("id_cartas_string")
							};
						}
					}
				}
			}
			return baralho;
		}
		public Baralho ObterBaralhoGlobalPorId(int IdBaralho)
		{
			Baralho baralho = null;
			using (var connection = new MySqlConnection(_connectionString))
			{
				connection.Open();
				string query = "SELECT id_baralho, id_cartas_string FROM baralho_global WHERE id_baralho = @Id";
				using (var command = new MySqlCommand(query, connection))
				{

					command.Parameters.AddWithValue("@Id", IdBaralho);

					using (var reader = command.ExecuteReader())
					{
						if (reader.Read())
						{
							baralho = new Baralho
							{
								Id = IdBaralho,
								Cartas = reader.GetString("id_cartas_string")
							};
						}
					}
				}
			}
			return baralho;
		}
		public List<Carta> ObterListCartas(Baralho baralho)
		{
			List<Carta> listcarta = new List<Carta>();
			Carta carta = null;
			CartaRepository cartaRepository = new CartaRepository();
			List<int> numcarta = cartaRepository.CriarListCartas(baralho);
			for (int i = 0; i < numcarta.Count; i++)
			{
				using (var connection = new MySqlConnection(_connectionString))
				{
					connection.Open();
					string query = "SELECT id_carta, dano, defesa, regeneração, imagem FROM cartas WHERE id_carta = @Id";
					using (var command = new MySqlCommand(query, connection))
					{

						command.Parameters.AddWithValue("@Id", numcarta[i]);

						using (var reader = command.ExecuteReader())
						{
							if (reader.Read())
							{
								carta = new Carta
								{
									Id = reader.GetInt32("id_carta"),
									Dano = reader.GetInt32("dano"),
									Defesa = reader.GetInt32("defesa"),
									Cura = reader.GetInt32("regeneração"),
									Imagem = ConversorImagem.ParaImagem((byte[])reader["imagem"]) // já corrigido
								};
								listcarta.Add(carta);
							}
						}
					}
				}	
			}
			return listcarta;
		}
		public void Embaralhar<T>(List<T> lista, int vezes)
		{
			for (int v = 0; v < vezes; v++)
			{
				for (int i = lista.Count - 1; i > 0; i--)
				{
					int j = rng.Next(i + 1);
					// troca os elementos de lugar
					(lista[i], lista[j]) = (lista[j], lista[i]);
				}
			}
		}
	}
}
